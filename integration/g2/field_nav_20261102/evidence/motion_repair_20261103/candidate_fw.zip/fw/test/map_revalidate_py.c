/* Host HAL only: actual CPU algorithm calls the same operations that the
 * hardware HAL supplies via the retained-depth and compare/invalidate ports. */
#include "map_ray_clear.h"
#include "map_revalidate.h"
#include <string.h>
#if defined(_WIN32)
#define EXPORT __declspec(dllexport)
#else
#define EXPORT __attribute__((visibility("default")))
#endif
typedef int (*read_cb_t)(int32_t,int32_t,int32_t*);
typedef int (*drop_cb_t)(int32_t,int32_t,int32_t,int32_t,int32_t);
static uint16_t depth[9600];static uint32_t stamp;static read_cb_t read_cb;static drop_cb_t drop_cb;
EXPORT void py_clear_set_callbacks(read_cb_t r,drop_cb_t d){read_cb=r;drop_cb=d;}
EXPORT void py_clear_depth(const uint16_t *data,uint32_t cap){memcpy(depth,data,sizeof depth);stamp=cap;}
EXPORT void py_clear_diag(uint32_t *v){map_revalidate_diagnostics(v);}
bool hal_clear_depth_begin(uint32_t cap){return cap==stamp;}
uint16_t hal_clear_depth_pixel(int u,int v){return u>=0 && u<160 && v>=0 && v<60?depth[v*160+u]:0;}
bool hal_clear_read(int32_t gx,int32_t gy,rc_cell_t *out){
 int32_t v[7];if(!read_cb || !read_cb(gx,gy,v))return false;
 *out=(rc_cell_t){gx,gy,(int16_t)v[0],(int16_t)v[1],(uint8_t)v[2],(uint8_t)v[3],(uint8_t)v[4],(uint8_t)v[5]};return true;
}
bool hal_clear_drop(const rc_cell_t *c){return drop_cb && drop_cb(c->gx,c->gy,c->tag,c->stamp,c->count);}
static uint16_t probe_depth(void *ctx,int u,int v){(void)ctx;return hal_clear_depth_pixel(u,v);}
static void probe_ray(void *ctx,int u,int v,int16_t out[3]){lidar_cal_pixel((const lidar_cal_t*)ctx,v*160+u,out);}
EXPORT void py_clear_probe(const uint32_t *lens,const int32_t *tf,const int32_t *cell,int32_t *out){
 lidar_cal_t cal;lidar_cal_init(&cal);lidar_cal_start(&cal,lens,true);
 rc_state_t state;rc_init(&state);rc_lens(&state,lens);
 rc_cell_t c={cell[0],cell[1],cell[2],cell[3],0,0,15,10};
 out[0]=rc_probe(&state,&c,(const int32_t(*)[3])tf,tf+9,1311,probe_depth,probe_ray,&cal);
 for(int i=0;i<12;i++)out[i+1]=(int32_t)state.diag[i];
}
