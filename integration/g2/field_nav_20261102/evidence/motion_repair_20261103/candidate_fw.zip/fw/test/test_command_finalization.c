#include <stdio.h>
#include <string.h>
#include "hal_sim.h"
#include "nav_task.h"
#include "motion_guard.h"
static nav_task_t nt;
static uint8_t map[NP_MAP_N * NP_MAP_N];
static int fails;
#define EXPECT(ok,name) do { printf("%s: %s (vx=%d wz=%d source=%d motion=%d)\n",name,(ok)?"PASS":"FAIL",nt.cmd.vx,nt.cmd.wz,nt.cmd_source,nt.motion_result);if(!(ok))fails++; }while(0)
static void fixture(void) {
    hal_map_info_t mi={0};mi.seq=1;mi.inv_res=1311;mi.res_mm=50;
    sim_map_fixture(map,&mi);
}
static void setup(int speed,int wall) {
    sim_reset();memset(map,0,sizeof map);
    if(wall)for(int y=62;y<=66;y++)map[y*NP_MAP_N+72]=NP_COST_LETHAL;
    fixture();nav_task_init(&nt);nav_task_set_mode(&nt,NAV_MODE_TRACK);
    nt.pose.cur=(nav_pose_t){0};nt.look_x=1000;nt.look_y=0;nt.v_prev=speed;
    nt.tgt.valid=true;nt.tgt.t_us=g_sim.now_us;nt.tgt.x=0;nt.tgt.y=700;
}
int main(void) {
    setup(0,0);nav_task_step(&nt,g_sim.now_us);
    EXPECT(nt.cmd_source==CMD_TRACK_FACE && nt.cmd.vx==0 && nt.cmd.wz>0,"track_face_preserves_turn");
    setup(300,1);nav_task_step(&nt,g_sim.now_us);
    EXPECT(nt.motion_result==MOTION_HAZARD && nt.cmd.vx==0 && nt.cmd.wz==0,"blocked_deceleration_is_rejected");
    setup(300,0);nav_task_set_mode(&nt,NAV_MODE_IDLE);nav_task_step(&nt,g_sim.now_us);
    EXPECT(nt.cmd.vx==250 && nt.cmd.wz==0 && nt.motion_result==MOTION_OK,"idle_decelerates_when_checked_free");
    setup(300,1);nav_task_set_mode(&nt,NAV_MODE_IDLE);nav_task_step(&nt,g_sim.now_us);
    EXPECT(nt.motion_result==MOTION_HAZARD && nt.cmd.vx==0,"idle_deceleration_cannot_bypass_hazard");
    setup(300,0);nav_task_set_mode(&nt,NAV_MODE_ESTOP);nav_task_step(&nt,g_sim.now_us);
    EXPECT(nt.cmd.vx==0 && nt.cmd.wz==0 && nt.cmd.mode==NAV_MODE_ESTOP,"estop_stays_immediate");
    setup(0,0);
    for(int y=0;y<NP_MAP_N;y++)for(int x=0;x<NP_MAP_N;x++) {
        int dx=(x-64)*50,dy=(y-64)*50,d2=dx*dx+dy*dy;
        if(d2>=400*400 && d2<=500*500)map[y*NP_MAP_N+x]=NP_COST_LETHAL;
    }
    fixture();nt.tgt.valid=false;nav_task_set_mode(&nt,NAV_MODE_SEARCH);nav_task_step(&nt,g_sim.now_us);
    EXPECT(nt.cmd_source==CMD_SEARCH && nt.cmd.vx==0 && nt.cmd.wz>0,"search_no_goal_preserves_in_place_scan");
    setup(0,0);nav_task_set_goal(&nt,2000,0);nt.lp_cfg.v_back=50;
    nt.recovering=true;nt.recover_dir=1;nt.recover_until_us=g_sim.now_us+1500000;
    nav_task_step(&nt,g_sim.now_us);
    EXPECT(nt.cmd_source==CMD_RECOVERY && nt.cmd.vx==-50 && nt.cmd.wz==0,"recovery_preserves_checked_direction");
    setup(0,0);nav_task_set_mode(&nt,NAV_MODE_SEARCH);nt.search_goal_valid=true;nt.path_valid=true;
    nav_task_set_goal(&nt,1130,230);
    EXPECT(nt.mode==NAV_MODE_GOTO && nt.goal_x==1130 && nt.goal_y==230 && !nt.search_goal_valid && !nt.path_valid,"search_to_goto_clears_old_plan");
    printf("failures=%d\n",fails);return fails?1:0;
}
