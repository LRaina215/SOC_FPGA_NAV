#define main command_finalization_regression
#include "test_command_finalization.c"
#undef main
#include <stdlib.h>
static void tick_at(uint32_t t) {g_sim.now_us=t;nav_task_step(&nt,t);}
static void fresh_x(int x) {nt.tgt.x=x;nt.tgt.y=0;nt.tgt.t_us=g_sim.now_us;nav_task_step(&nt,g_sim.now_us);}
int main(void) {
    command_finalization_regression();
    setup(300,0);tick_at(2001000);
    EXPECT(nt.mode==NAV_MODE_TRACK && nt.cmd_source==CMD_HOLD && nt.cmd.vx==270,"two_second_gap_waits_and_brakes");
    for(int i=1;i<=10;i++)tick_at(2001000+i*100000);
    EXPECT(nt.mode==NAV_MODE_TRACK && nt.cmd.vx==0,"short_loss_stays_track_at_rest");
    tick_at(5001001);EXPECT(nt.mode==NAV_MODE_SEARCH,"five_second_loss_enters_search");
    setup(0,0);fresh_x(1300);int h0=nt.track_holding;
    g_sim.now_us+=100000;fresh_x(1360);int h1=nt.track_holding;
    g_sim.now_us+=100000;fresh_x(1250);int h2=nt.track_holding;
    g_sim.now_us+=100000;fresh_x(1190);int h3=nt.track_holding;
    g_sim.now_us+=100000;fresh_x(1300);int h4=nt.track_holding;
    EXPECT(h0 && !h1 && !h2 && h3 && h4,"hold_200_start_350_hysteresis");
    setup(0,0);fresh_x(2000);int gx=nt.goal_x,gy=nt.goal_y,stable=1;
    for(int i=1;i<=12;i++){g_sim.now_us+=100000;fresh_x(2000+(i%2?100:-100));if(nt.goal_x!=gx || nt.goal_y!=gy)stable=0;}
    EXPECT(stable && nt.cmd.vx>0,"small_goal_jitter_keeps_route_and_forward_command");
    setup(0,0);nt.tgt.valid=false;pose_odom(&nt.pose,0,0,0,1000000);
    target_update(&nt.tgt,&nt.pose,true,2000,0,0,7,0,1000000);
    int maxx=0,maxy=0;
    for(int i=1;i<=20;i++){
        uint32_t t=1000000+i*100000;pose_odom(&nt.pose,0,0,0,t);
        target_update(&nt.tgt,&nt.pose,true,2000+(i%2?120:-120),i%2?80:-80,0,7,0,t);
        if(abs(nt.tgt.x-2000)>maxx)maxx=abs(nt.tgt.x-2000);if(abs(nt.tgt.y)>maxy)maxy=abs(nt.tgt.y);
    }
    EXPECT(maxx<80 && maxy<60,"target_position_filter_reduces_120mm_jitter");
    printf("filter_max_error_x=%d y=%d failures=%d\n",maxx,maxy,fails);return fails?1:0;
}
