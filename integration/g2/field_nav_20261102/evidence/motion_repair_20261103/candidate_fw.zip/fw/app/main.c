/* 软核入口（PicoRV32 SoC，启动代码 / 链接脚本 / 控制台在 fw/bsp）。 */
#include "nav_app.h"
#include "hal.h"
#include "soc.h"
#include "support_guard.h"

int main(void)
{
#ifdef APP_BENCH_STATIONARY
    con_printf("\r\nnav fw BENCH (stationary odometry) " __DATE__ " " __TIME__ "  RAM %u KB\r\n", SOC_RAM_SIZE / 1024);
#else
    con_printf("\r\nnav fw " __DATE__ " " __TIME__ "  RAM %u KB\r\n", SOC_RAM_SIZE / 1024);
#endif
    nav_app_init();
    uint32_t t_log = hal_time_us(), loops = 0, max_us = 0, t_prev = t_log, n_gen = 0, n_xs = 0, n_xok = 0;
    for (;;) {
        nav_app_poll();
        uint32_t now = hal_time_us(), d = now - t_prev;
        t_prev = now;
        if (d > max_us) max_us = d;
        loops++;
        SOC_STATUS = loops;
        if (g_app.lcal.n_gen != n_gen) {
            n_gen = g_app.lcal.n_gen;
            con_printf("lidar LUT ready (%s lens), %u ms\r\n", g_app.lcal.from_dev ? "device" : "M60 default",
                       g_app.lcal.gen_us / 1000u);
        }
        if (g_app.xl.n_start != n_xs) {
            n_xs = g_app.xl.n_start;
            con_printf("lidar start #%u (tcp -> %u.%u.%u.%u:7787)\r\n", n_xs, g_app.xl.net.lidar_ip >> 24,
                       (g_app.xl.net.lidar_ip >> 16) & 255u, (g_app.xl.net.lidar_ip >> 8) & 255u, g_app.xl.net.lidar_ip & 255u);
        }
        if (g_app.xl.n_ok != n_xok) {
            n_xok = g_app.xl.n_ok;
            con_printf("lidar start ok (%u)\r\n", n_xok);
        }
        if ((uint32_t)(now - t_log) >= 1000000u) {
            t_log = now;
            const nav_task_t *nt = &g_app.nt;
            con_printf("t=%u s  loop %u/s max %u us  frames %u msgs %u  mode %d state %d  loc %d  pose %d,%d mm  lut %d\r\n",
                       now / 1000000u, loops, max_us, g_app.n_frames, g_app.n_msgs, nt->mode, nt->state,
                       nav_app_have_prior() ? (int)g_app.loc.st : 0, nt->pose.cur.x, nt->pose.cur.y,
                       (int)lidar_cal_ready(&g_app.lcal));
            con_printf("  nav map %d stale %d path %d src %d motion %d lp_vx %d lp_wz %d cmd %d,%d  rec %d\r\n",
                       (int)nt->have_map, (int)nt->stale, (int)nt->path_valid, (int)nt->cmd_source,
                       (int)nt->motion_result, (int)nt->lp.cmd.vx, (int)nt->lp.cmd.wz, (int)nt->cmd.vx, (int)nt->cmd.wz,
                       (int)nt->recovering);
#if !APP_COMPACT_TELEMETRY
            con_printf("  scan act %d exit %d settle %d fail %d need %d odo_age %d ms odo vx %d wz %d\r\n",
                       (int)nt->scan_active, (int)nt->scan_exit_valid, (int)nt->scan_settling, (int)nt->scan_failed,
                       (int)support_scan_needed(), nt->pose.have_odo ? (int)((now - nt->pose.last_odo_us) / 1000u) : -1,
                       (int)nt->pose.odo_vx, (int)nt->pose.odo_wz);
#endif
            con_printf("  loc q %d ema %d pts %u skip %u tskip %u\r\n", g_app.loc.q_last, (int)(g_app.loc.q_ema / 256),
                       (unsigned)g_app.loc.n_pts, (unsigned)g_app.n_skip, (unsigned)g_app.n_time_skip);
            con_printf("  match valid %u in %u cost %u align %u fail %u strong %u\r\n",
                       (unsigned)g_app.pm.n_valid, (unsigned)g_app.pm.n_in_best, (unsigned)g_app.pm.cost_best,
                       (unsigned)g_app.loc.n_align, (unsigned)g_app.loc.n_align_fail, (unsigned)g_app.dr_strong);
            con_printf("  imu ok %u bad %u att %d pitch %d roll %d cdeg\r\n",
                       (unsigned)g_app.imu.n_ok, (unsigned)g_app.imu.n_bad, (int)nt->pose.have_att,
                       (int)((int32_t)(int16_t)nt->pose.cur.pitch * 18000 / 32768),
                       (int)((int32_t)(int16_t)nt->pose.cur.roll * 18000 / 32768));
#if !APP_COMPACT_TELEMETRY
            con_printf("  tmax step %u look %u chk %u frm %u mt %u host %u map %u ms\r\n",
                       (unsigned)(g_app.tmax_step / 1000u), (unsigned)(nt->t_look_max / 1000u),
                       (unsigned)(nt->t_chk_max / 1000u), (unsigned)(g_app.tmax_frame / 1000u),
                       (unsigned)(g_app.tmax_match / 1000u), (unsigned)(g_app.tmax_host / 1000u),
                       (unsigned)(g_app.tmax_map / 1000u));
#endif
            con_printf("  tq odo %u att %u turn %u  ovf %u rs %u lag %d ms  bias %d yaw %d cdeg\r\n",
                       (unsigned)g_app.n_tq_odo, (unsigned)g_app.n_tq_att, (unsigned)g_app.n_turn_skip,
                       (unsigned)g_app.imu_ovf, (unsigned)g_app.n_imu_resync,
                       nt->pose.have_att ? (int)((int32_t)(now - nt->pose.imu_t_us) / 1000) : -1,
                       (int)(nt->pose.wz_bias_q8 / 256),
                       (int)((int32_t)(int16_t)nt->pose.cur.yaw * 18000 / 32768));
#if !APP_COMPACT_TELEMETRY
            con_printf("  look %d,%d i %d/%d goal %d,%d hold %d,%d  align q %d amb %d da %d  uns %u\r\n",
                       (int)nt->look_x, (int)nt->look_y, (int)nt->look_i, nt->path.n,
                       (int)nt->goal_x, (int)nt->goal_y, nt->hold_ref ? (int)nt->hold_x : 0,
                       nt->hold_ref ? (int)nt->hold_y : 0, g_app.loc.res_q, g_app.loc.res_q2,
                       (int)((int32_t)g_app.loc.res_da * 18000 / 32768), (unsigned)g_app.n_unsettled);
#endif
#if APP_COMPACT_TELEMETRY
            con_printf("  obs %u/%u phase %u\r\n",nt->observe_completed,nt->observe_started,nt->recheck_phase);
#endif
            con_printf("  inv mfail %u(%u) pbusy %u stall %u dr %d  lidar acc %u rej %u(q %u) edge %u  live %u%s\r\n",
                       nt->n_mfail, nt->last_mfail, nt->n_pbusy, nt->n_stall, (int)g_app.dead_reckon, g_app.n_dr_acc,
                       g_app.n_dr_rej, g_app.n_dr_lowq, g_app.n_dr_edge, nt->gm.n_live, nt->gm.live_on ? " on" : "");
            g_app.tmax_step = g_app.tmax_frame = g_app.tmax_match = g_app.tmax_host = g_app.tmax_map = 0;
            g_app.nt.t_look_max = g_app.nt.t_chk_max = 0;
            SOC_LED = (SOC_LED + 1u) & 0xFu;
            loops = 0;
            max_us = 0;
        }
    }
    return 0;
}
