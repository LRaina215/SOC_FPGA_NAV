#include "map_revalidate.h"
#include "nav_search_checkpoint.h"
#include "nav_app.h"
#include "hal.h"
#include "support_guard.h"
#include "host_link_guard.h"
#ifndef APP_FLAT_FRAMES
#define APP_FLAT_FRAMES 1
#endif

nav_app_t g_app;
bool g_nav_search_interrupted;
static uint8_t host_rx_buf[PROTO_MAX_LEN]; /* moved from nav_app_poll; same capacity */
static int host_pending_len;
static uint32_t host_pending_rx;

static void app_match_update(int32_t dx,int32_t dy,int32_t da,int32_t cx,int32_t cy)
{
    if (g_app.lf_fixed) hal_match_lf_center_mm(g_app.lf_fixed_x_mm, g_app.lf_fixed_y_mm);
    else hal_match_lf_forward(g_app.lf_forward_mm,g_app.nt.pose.cur.yaw);
    hal_match_update(dx,dy,da,cx,cy);
}
bool nav_app_have_prior(void) { return g_app.prx.state == PRIOR_READY; }

/* fixed=true 时窗口中心固定在里程计系 (x_mm, y_mm)，forward_mm 不用 */
bool nav_app_set_slf_window_mode(bool fixed,int32_t forward_mm,int32_t x_mm,int32_t y_mm,int32_t zhi_mm)
{
    if (forward_mm<0 || forward_mm>3000 || zhi_mm<APP_ZLO_ODOM || zhi_mm>1500 ||
        x_mm<-10000 || x_mm>10000 || y_mm<-10000 || y_mm>10000 ||
        g_app.nt.mode!=NAV_MODE_IDLE || g_app.pm_pend || g_app.pm_run ||
        nav_app_have_prior() || g_app.prx.state==PRIOR_RECV) return false;
    if(g_app.lf_forward_mm!=forward_mm || g_app.match_zhi!=zhi_mm || g_app.lf_fixed!=fixed ||
       (fixed && (g_app.lf_fixed_x_mm!=x_mm || g_app.lf_fixed_y_mm!=y_mm)))
        hal_prior_enable(false,0,0); // clear accumulated old-height/window SLF, EM unchanged
    g_app.lf_forward_mm=forward_mm;g_app.match_zhi=zhi_mm;
    g_app.lf_fixed=fixed;g_app.lf_fixed_x_mm=x_mm;g_app.lf_fixed_y_mm=y_mm;
    hal_match_zband(APP_ZLO_ODOM,zhi_mm);return true;
}
bool nav_app_set_slf_window(int32_t forward_mm,int32_t zhi_mm)
{
    return nav_app_set_slf_window_mode(false,forward_mm,0,0,zhi_mm);
}
void nav_app_init(void)
{
    nav_task_init(&g_app.nt);
    host_link_guard_init(&g_host_link_guard,hal_time_us());
    g_app.nt.async_gmap=true;
    hal_map_flat_ground(); /* 11-01 平地测试：放宽台阶/粗糙度阈值，只把真障碍判为致命 */
    support_reset(0); support_enable(false); /* 10-31 用户要求：关掉轮下支撑检查与原地转圈，直接按代价图导航 */
    imu_parser_init(&g_app.imu, (imu_proto_t)APP_IMU_PROTO);
    if (APP_IMU_BAUD_DIV > 0) hal_imu_config(APP_IMU_BAUD_DIV);
    uint32_t now = hal_time_us();
    g_app.t_plan = now;
    g_app.t_status = now;
    g_app.use_imu_yaw = false;
    pm_default_cfg(&g_app.pm_cfg);
    g_app.pm_cfg.enable = true;             /* SLF 匹配定位（硬件打分不可用时 hal_match_eval 返回 false，自动退化为纯航位推算） */
#if defined(APP_BENCH_STATIONARY) && defined(APP_BENCH_NO_MATCH)
    /* Bench build only: keep the pose exactly fixed so static map captures are not smeared by matching. */
    g_app.pm_cfg.enable = false;
#endif
    g_app.pm_cfg_prior = g_app.pm_cfg;
    g_app.pm_cfg_prior.gain_q8 = 208;       /* 先验图是固定的真值，不会"自己拉自己"，可以修得更快 */
    /* 退化判定门限放低：先验图里沿墙方向的代价是真平的（没有自建图质心跳动的噪声），少量垂直结构
     * （远处的路沿、箱体正面）就足以约束前进方向；600 时平台上沿行驶方向漂 0.28 m，200 时最大 6 cm */
    g_app.pm_cfg_prior.min_curv = 200;
    g_app.lf_forward_mm = APP_LF_FORWARD_MM;
    g_app.match_zhi = APP_ZHI;
    g_app.zband_lo = -600;
    g_app.zband_hi = 1200;
    g_app.anchor_gain = 64;
    g_app.anchor_hl = 60;                   /* 足迹采样点：轮子着地处前后 ±60 mm */
    g_app.anchor_hw = 135;                  /* 轮距 270 mm（胎面中心，tools/robot_calib.py） */
    prior_rx_init(&g_app.prx);
    loc_default_cfg(&g_app.loc.cfg);
    loc_init(&g_app.loc);
    hal_lidar_init();
    hal_match_zband(APP_ZLO_ODOM,g_app.match_zhi);
    lidar_cal_init(&g_app.lcal);            /* 先按 M60 缺省内参生成，收到雷达自带内参后按需重算 */
    g_app.lcal_budget = 8;                  /* 软核每像素约 0.1 ms：每轮 8 个，整张表约 1–2 s */
    xt_link_init(&g_app.xl, hal_time_us());
}

/* 位姿进入新坐标系（SET_POSE / 对准完成）：旧坐标系下的局部观测全部作废 */
static void frame_jumped(nav_task_t *nt)
{
    astar_cancel();
    map_revalidate_reset();nt->recheck_phase=0;
    support_frame_jump();
    nt->scan_active=nt->scan_settling=nt->scan_failed=false;
    nt->scan_exit_valid=false;
    nt->terrain_frame=(local_frame_t){0};
    hal_map_clear();
    gmap_clear_obs(&nt->gm);
    nt->path_valid = false;
    nt->have_map = false;
    g_app.anchor_wait = false;
    hal_map_info_t mi;
    if (hal_map_info(&mi)) { nt->stale = true; nt->stale_seq = mi.seq; }
    target_init(&nt->tgt, TARGET_LOST_US, TARGET_STANDOFF_MM);
    explore_seen_reset(&nt->exp);
}

static void send_ack(void)
{
    uint8_t b[16];
    int n = proto_build_map_ack(b, g_app.prx.next, g_app.prx.state);
    hal_host_send(b, n);
}

static void wait_anchor(void)
{
    hal_map_info_t mi = {0};
    hal_map_info(&mi);
    g_app.anchor_wait = true;
    g_app.anchor_seq = mi.seq;
}

/* 第二遍复用保留的深度帧：只按已接受的采集位姿融合，不重新提取匹配点。 */
/* 本帧时刻姿态在突变窗口内：照常用于定位匹配，但不融合进高程图（晃动时整帧倾斜会造假台阶） */
static bool s_frame_unsettled;
static void finish_fusion(bool valid)
{
    if (!g_app.fuse_held) return;
    if (s_frame_unsettled && valid) { g_app.n_unsettled++; valid = false; }
    nav_pose_t at = valid ? g_app.pm_at : g_app.nt.pose.cur;
    if(!g_app.nt.gm.has_prior) local_frame_pose(&g_app.nt.terrain_frame,&at,&at);
    int32_t r[3][3], t[3];
    pose_lidar_tf(&g_app.nt.pose, &at, r, t);
    hal_map_info_t mi; hal_map_info(&mi);
    uint16_t inv = mi.inv_res ? mi.inv_res : 1311;
    int32_t cx = (int32_t)(((int64_t)at.x*inv)>>16), cy = (int32_t)(((int64_t)at.y*inv)>>16);
    if(valid) map_revalidate_before_fuse(&g_app.nt,&g_app.lcal,r,t,at.t_us);
    hal_lidar_stage(HAL_LIDAR_FUSE_ONLY);
    if (valid) wait_anchor();
    hal_lidar_commit(r, t, cx, cy, valid ? at.z+g_app.zband_lo : 1, valid ? at.z+g_app.zband_hi : 0,at.t_us);
    g_app.fuse_held = false;
}

static void on_msg(nav_task_t *nt, const proto_msg_t *m, uint32_t rx_us)
{
    switch (m->type) {
    case MSG_SET_POSE:
        g_app.have_fix = false;
        g_app.pose_seeded = nav_app_have_prior();
        g_app.dr_agree = g_app.dr_strong = 0;
        loc_init(&g_app.loc);          /* 新起点不能继承上一地点的质量/歧义/重试状态 */
        g_app.turning = false;
        pose_set(&nt->pose, m->u.pose.x, m->u.pose.y, ANGLE_FROM_CDEG(m->u.pose.yaw_cdeg));
        frame_jumped(nt);
        if (g_app.pm_pend || g_app.pm_run) g_app.pm_stale = true;
        if (nav_app_have_prior() && (m->u.pose.flags & 1))   /* 搜索范围限制在 ±0.4 m / ±8°：大范围搜索会跳到相似结构上 */
            loc_start_align(&g_app.loc, nav_clamp32(m->u.pose.range_mm > 0 ? m->u.pose.range_mm : 300, 1, 400),
                            nav_clamp32(m->u.pose.range_cdeg > 0 ? m->u.pose.range_cdeg : 600, 1, 800) * 182 / 100);
        else if (nav_app_have_prior())
            g_app.loc.st = LOC_OK;                   /* 主机保证位姿准确：直接跟踪 */
        break;
    case MSG_SLF_CONFIG: {
        uint32_t result=0; // query0/applied1/busy2/range3/prior4
        if(m->u.slf.set) {
            int32_t d=m->u.slf.forward_mm,z=m->u.slf.zhi_mm;
            bool fixed=m->u.slf.fixed!=0;
            if(d<0||d>3000||z<APP_ZLO_ODOM||z>1500) result=3;
            else if(nav_app_have_prior()||g_app.prx.state==PRIOR_RECV) result=4;
            else result=nav_app_set_slf_window_mode(fixed,d,m->u.slf.fixed_x_mm,m->u.slf.fixed_y_mm,z)?1:2;
        }
        uint8_t reply[20];
        /* 固定窗口时 d 字段回报 -1；profile 低字节 08 表示支持固定窗口 */
        int n=proto_build_slf_ack(reply,result,g_app.lf_fixed?-1:g_app.lf_forward_mm,g_app.match_zhi,0x534C0108u);
        hal_host_send(reply,n);break;
    }
    case MSG_MAP_BEGIN:
        g_app.pose_seeded = false;
        g_app.dr_agree = g_app.dr_strong = 0;
        g_app.have_fix = false;
        prior_rx_begin_profile(&g_app.prx, &nt->gm, m->u.map_begin.total,(int16_t)g_app.match_zhi);
        hal_match_zband(APP_ZLO_ODOM, g_app.match_zhi);
        loc_init(&g_app.loc);
        if (g_app.pm_pend || g_app.pm_run) g_app.pm_stale = true;
        send_ack();
        break;
    case MSG_MAP_DATA:
        prior_rx_data(&g_app.prx, &nt->gm, m->u.map_data.offset, m->u.map_data.data, m->u.map_data.n);
        send_ack();
        break;
    case MSG_MAP_END:
        if (prior_rx_end(&g_app.prx, &nt->gm) == PRIOR_READY) hal_match_zband(APP_ZLO_PRIOR, g_app.match_zhi);
        loc_init(&g_app.loc);                        /* 等 SET_POSE */
        send_ack();
        break;
    case MSG_MAP_CLEAR:
        g_app.pose_seeded = false;
        g_app.dr_agree = g_app.dr_strong = 0;
        prior_rx_clear(&g_app.prx, &nt->gm);
        hal_match_zband(APP_ZLO_ODOM, g_app.match_zhi);
        loc_init(&g_app.loc);
        send_ack();
        break;
    default:
        nav_task_on_msg(nt, m, rx_us);
        break;
    }
}

/* This lock requests controlled zero targets; it does not disable balance or set SAFE.ESTOP. */
static void apply_host_link_lock(uint32_t now)
{
    static bool zero_published_for_lock;
    if(!host_link_guard_poll(&g_host_link_guard,now)) {
        zero_published_for_lock=false;
        return;
    }
    nav_task_t *nt=&g_app.nt;
    nav_mode_t mode=g_host_link_guard.timed_out?NAV_MODE_ESTOP:NAV_MODE_IDLE;
    if(nt->mode!=mode) nav_task_set_mode(nt,mode);
    nt->tgt.valid=false;nt->wp_n=nt->wp_i=0;nt->wp_loop=false;
    nt->path_valid=false;nt->path.n=0;nt->search_goal_valid=false;
    nt->hold_wz=0;g_app.turning=false;
    nt->cmd=(nav_cmd_t){0,0,0,(uint8_t)mode};
    support_note_cmd(&nt->cmd);
    /* Publish on the lock edge instead of waiting for the100ms planner tick.
       hal_send_cmd keeps its independent final guard and hardware STOP path. */
    if(!zero_published_for_lock) {
        hal_send_cmd(&nt->cmd);
        zero_published_for_lock=true;
    }
}

/* Only a no-op heartbeat can continue the frozen frontier view. Other
 * packets remain in the existing buffer until nav_task_step has unwound. */
bool nav_app_search_checkpoint(void)
{
    if(!host_pending_len) {
        uint32_t rx;
        int len=hal_host_recv(host_rx_buf,sizeof host_rx_buf,&rx);
        if(len>0) {
            proto_msg_t m;
            if(proto_parse(host_rx_buf,len,&m)) {
                if(m.type==MSG_TARGET && !m.u.target.found) {
                    if(host_link_guard_observe(&g_host_link_guard,&m,hal_time_us(),rx)) g_app.n_msgs++;
                } else { host_pending_len=len;host_pending_rx=rx; }
            }
        }
    }
    apply_host_link_lock(hal_time_us());
    if(host_pending_len || g_host_link_guard.locked) {
        g_nav_search_interrupted=true;
        nav_cmd_t zero={0,0,0,(uint8_t)g_app.nt.mode};
        hal_send_cmd(&zero);
        return false;
    }
    return true;
}

/* Bound ordinary receive work, including invalid/rejected packets.
 * Checkpoints keep their original one-packet/no-op-heartbeat contract. */
static void drain_host_messages(unsigned max_packets)
{
    uint32_t rx_us;
    int len;
    for(unsigned handled=0;handled<max_packets;handled++) {
        if(host_pending_len) {
            /* This raw payload was popped at a checkpoint. Consume it first,
             * after the planner's local-coordinate view has unwound. */
            len=host_pending_len;rx_us=host_pending_rx;host_pending_len=0;
        } else len=hal_host_recv(host_rx_buf,sizeof host_rx_buf,&rx_us);
        if(len<=0) break;
        proto_msg_t m;
        bool accepted=proto_parse(host_rx_buf,len,&m) &&
            host_link_guard_observe(&g_host_link_guard,&m,hal_time_us(),rx_us);
        /* Preserve observe-before-poll for fresh queued arrivals. Invalid
         * packets cannot defer the timeout publication until FIFO empty. */
        apply_host_link_lock(hal_time_us());
        if(accepted) {
            on_msg(&g_app.nt,&m,rx_us);
            g_app.n_msgs++;
        }
        /* A single handler may be expensive; inspect actual time on return. */
        apply_host_link_lock(hal_time_us());
    }
}

#define APP_TURN_SETTLE_US 400000u   /* 转向结束后再等这么久才恢复匹配（车头摆动衰减） */
#define APP_LOC_BLIND_US 1500000u    /* 定位正常却这么久没处理到可用帧：如实降为退化 */
#define APP_DR_MAX_MM 2500           /* 定位丢失后靠推算最多再走这么远 */
#define APP_DR_MAX_US 30000000u      /* 或这么久 */

/* IMU 字节泵：读空字节 FIFO（每次最多 512 字节）。FIFO 溢出过，或突发时间戳与读取时刻对不上
 * （时间戳 FIFO 与字节 FIFO 错位的表现），就把两个 FIFO 一起清空重新配对，解析器从下一突发重新对齐。 */
static void imu_resync(void)
{
    hal_imu_resync();
    g_app.imu.n = 0;
    g_app.n_imu_resync++;
}

static void imu_pump(void)
{
    nav_task_t *nt = &g_app.nt;
    uint32_t ovf = hal_imu_ovf();
    if (ovf != g_app.imu_ovf) { g_app.imu_ovf = ovf; imu_resync(); return; }
    uint8_t b;
    bool first;
    uint32_t tb = 0;
    for (int i = 0; i < 512 && hal_imu_byte(&b, &first, &tb); i++) {
        if (first) {
            /* 按时读取时，突发时间戳离现在不超过 FIFO 里还排着的突发数 × 10 ms（再留 15 ms） */
            int32_t age = (int32_t)(hal_time_us() - tb);
            if (age < -2000 || age > 15000 + (int32_t)(hal_imu_level() / 22u + 1u) * 10000) { imu_resync(); return; }
        }
        if (imu_parser_feed(&g_app.imu, b, first, tb))
            pose_imu_att(&nt->pose, g_app.imu.yaw, g_app.imu.pitch, g_app.imu.roll, g_app.use_imu_yaw,
                         g_app.imu.att_t_us);
        if (g_app.imu.gyro_new) {
            g_app.imu.gyro_new = false;
            pose_imu_gyro(&nt->pose, g_app.imu.gx, g_app.imu.gy, g_app.imu.gyro_t_us);
        }
    }
}

#ifndef APP_DR_PRIMARY
#define APP_DR_PRIMARY 1
#endif
#define APP_DR_Q 35            /* 采纳雷达修正的最低内点率 %（11-02 实测：起点站立时 45–68，原门限 55 一帧都没采纳） */
#define APP_LIVE_US 3000000u   /* 最近这么久内采纳过雷达修正，实时障碍层才生效 */
#define APP_DR_AGREE 3         /* 连续这么多帧都合格才采纳 */
#define APP_DR_RATE_MM 20      /* 雷达最多以 20 mm/s 把位置往它认为的方向拉 */
#define APP_DR_RATE_ANG 91     /* 航向最多 0.5°/s（angle/s） */
/* 推算为主时雷达匹配的采纳条件：本帧内点率 >= APP_DR_Q、连续 APP_DR_AGREE 帧都合格；采纳时修正量减半，
 * 并按时间限速（即使匹配一直错，位置也只会慢慢偏，不会跳）。不合格的修正直接丢弃，位姿照推算走。
 * 解落在搜索窗边上（约束充分的方向上误差超出了窗口）也采纳：方向是对的，限速后一点点拉回来。
 * 11-02 起点站立时内点率 63–73，却因每帧都在窗边被全部丢弃，推算误差一旦超出窗口就再也修不回来。 */
static bool dr_gate(bool ok, const hal_match_res_t *res)
{
    pm_stat_t *m = &g_app.pm;
    uint32_t now = hal_time_us();
    if ((uint32_t)(now - g_app.t_dr_frame) > 500000u)
        g_app.dr_agree = g_app.dr_strong = 0;
    g_app.t_dr_frame = now;
    uint32_t np = res ? res[0].n_pts : 0;
    int q = (ok && np >= (uint32_t)g_app.loc.cfg.min_pts) ? (int)(m->n_in_best * 100 / np) : 0;
    bool good = ok && q >= APP_DR_Q;
    bool strong = good && q >= g_app.loc.cfg.q_ok && !m->at_edge;
    if (ok && m->at_edge) g_app.n_dr_edge++;
    g_app.dr_agree = good ? (uint8_t)nav_min32(g_app.dr_agree + 1, 255) : 0;
    bool coherent = nav_abs32(m->dx - g_app.dr_dx) <= 25 && nav_abs32(m->dy - g_app.dr_dy) <= 25 &&
                    nav_abs32(m->dyaw - g_app.dr_da) <= 128;
    g_app.dr_strong = strong ? (coherent ? (uint8_t)nav_min32(g_app.dr_strong + 1, 255) : 1) : 0;
    g_app.dr_dx = (int16_t)m->dx; g_app.dr_dy = (int16_t)m->dy; g_app.dr_da = (int16_t)m->dyaw;
    if (!good || g_app.dr_agree < APP_DR_AGREE) {
        if (ok) {
            g_app.n_dr_rej++;
            if (q < APP_DR_Q) g_app.n_dr_lowq++;
        }
        return false;
    }
    uint32_t dt = now - g_app.t_dr_last;
    if (dt > 200000u) dt = 200000u;
    g_app.t_dr_last = now;
    /* Before the dead-reckoning-only policy, well-constrained lidar matches
     * used the solver's normal gain. Retain that path after three strong
     * frames, with bounded per-frame changes. A permanently tiny trim cannot
     * recover prediction error even when the match has become reliable. */
    if (g_app.dr_strong >= APP_DR_AGREE) {
        m->dx = nav_clamp32(m->dx, -50, 50);
        m->dy = nav_clamp32(m->dy, -50, 50);
        m->dyaw = nav_clamp32(m->dyaw, -182, 182);
        g_app.n_dr_acc++;
        return true;
    }
    int32_t cmm = 1 + (int32_t)(APP_DR_RATE_MM * dt / 1000000u), cang = 1 + (int32_t)(APP_DR_RATE_ANG * dt / 1000000u);
    m->dx = nav_clamp32(m->dx / 2, -cmm, cmm);
    m->dy = nav_clamp32(m->dy / 2, -cmm, cmm);
    m->dyaw = nav_clamp32(m->dyaw / 2, -cang, cang);
    g_app.n_dr_acc++;
    return true;
}

static bool recover_idle_match(nav_task_t *nt, loc_t *lc, uint32_t now)
{
    if (nt->mode == NAV_MODE_IDLE && nt->cmd.vx == 0 && nt->cmd.wz == 0) {
        /* Manual view changes need local reacquisition, not an indefinite
         * degraded state in the tiny tracking window. No motion is issued. */
        loc_start_align(lc, lc->cfg.reloc_mm, lc->cfg.reloc_ang);
        g_app.have_fix = g_app.dead_reckon = false;
        g_app.dr_agree = g_app.dr_strong = 0;
        return true;
    }
    lc->st = LOC_DEGRADED;
    lc->degr_since = now;
    return false;
}

/* 转向后头几帧放宽跟踪角度窗到 ±2.8°（2 × 1.4°），接住陀螺在转向中积累的航向误差 */
static void limit_aux_correction(pm_stat_t *c)
{
    /* A declared starting pose is the frontend reference. Even a successful
     * auxiliary search must not replace it with an abrupt multi-decimetre jump. */
    c->dx = nav_clamp32(c->dx, -25, 25);
    c->dy = nav_clamp32(c->dy, -25, 25);
    c->dyaw = nav_clamp32(c->dyaw, -182, 182);
}

static void apply_pose_policy(nav_task_t *nt, bool prior)
{
    const bool relative = nt->mode == NAV_MODE_TRACK || nt->mode == NAV_MODE_SEARCH;
    /* IMU+encoders are the frontend. A declared map pose is sufficient for a
     * map goal; lidar alignment/quality is an auxiliary observation. Relative
     * target tasks use live local costs and never an unregistered static map. */
    nt->use_gmap = !relative;
    nt->hold = prior && !g_app.pose_seeded && !relative;
    nt->slow = prior && g_app.pose_seeded && g_app.loc.st != LOC_OK && !relative;
    g_app.dead_reckon = prior && g_app.pose_seeded && g_app.loc.st != LOC_OK;
}

static uint8_t reported_loc_state(bool prior)
{
    if (!prior) return LOC_ODOM;
    if (g_app.pose_seeded && (g_app.loc.st == LOC_ALIGN || g_app.loc.st == LOC_LOST))
        return LOC_DEGRADED; /* known initial frame; background lidar recovery */
    return (uint8_t)g_app.loc.st;
}

static const pm_cfg_t *track_cfg(const pm_cfg_t *pc)
{
    static pm_cfg_t wide;
    if (!g_app.pm_wide) return pc;
    wide = *pc;
    wide.step_ang = 256;
    return &wide;
}

static inline void tmax(uint32_t *m, uint32_t t0)
{
    uint32_t d = hal_time_us() - t0;
    if (d > *m) *m = d;
}

void nav_app_poll(void)
{
    nav_task_t *nt = &g_app.nt;
    loc_t *lc = &g_app.loc;
    uint32_t now = hal_time_us();
    apply_host_link_lock(now);
    const bool prior = nav_app_have_prior();
    const bool receiving = g_app.prx.state == PRIOR_RECV;

    /* 1. 底盘里程计 */
    int16_t vx, vy, wz;
    uint32_t t;
    while (hal_odom(&vx, &vy, &wz, &t)) pose_odom(&nt->pose, vx, vy, wz, t);
#ifdef APP_BENCH_STATIONARY
    /* Bench build only: the chassis is held still with its controller stopped, which stops
     * odometry. Zero-velocity samples keep lidar frames posed; real odometry always wins. */
    if (!nt->pose.have_odo || (uint32_t)(now - nt->pose.last_odo_us) > 20000u)
        pose_odom(&nt->pose, 0, 0, 0, now);
#endif

    /* 2. IMU 姿态 */
    imu_pump();
    /* 原地转向：指令是原地转，或陀螺读数超过 0.5 rad/s（静止平衡时偏航摆动约 ±0.15 rad/s） */
    bool turn_now = (nt->cmd.vx == 0 && nav_abs32(nt->cmd.wz) >= 300) || nav_abs32(nt->pose.odo_wz) > 500;
    if (turn_now) { g_app.t_turn_end = now; g_app.was_turn = true; pose_bias_feedback_reset(&nt->pose); }
    bool turn_recent = g_app.was_turn && (uint32_t)(now - g_app.t_turn_end) < APP_TURN_SETTLE_US;
    if (g_app.was_turn && !turn_recent) { g_app.was_turn = false; g_app.wide_left = 3; }

    /* 3. 雷达帧：先提结构点，匹配门控接受后按修正位姿重读同帧融合。 */
    if (g_app.anchor_wait) {
        hal_map_info_t mi;
        if (hal_map_info(&mi) && mi.seq != g_app.anchor_seq) {
            g_app.anchor_wait = false;
            nav_pose_t local=nt->pose.cur;
            if(!prior) local_frame_pose(&nt->terrain_frame,&local,&local);
            pose_anchor_z_at(&nt->pose,&local,g_app.anchor_hl,g_app.anchor_hw,g_app.anchor_gain);
        }
    }
    xt_link_poll(&g_app.xl, now);
    lidar_cal_poll(&g_app.lcal, g_app.lcal_budget);
    uint32_t ft;
    /* 等到帧时刻之后的姿态已到达（IMU 50 Hz，最多等 100 ms）再处理：否则帧时刻恰逢姿态突变时，
     * 突变还没被检测到，这一帧就会带着旧姿态融合 */
    bool att_ready = false;
    /* 上一帧的匹配未结束时不提交新帧（点缓冲还在用） */
    if (!g_app.pm_pend && !g_app.pm_run && hal_lidar_waiting(&ft))
        att_ready = !nt->pose.have_att || (int32_t)(nt->pose.imu_t_us - ft) >= 0 || (uint32_t)(now - ft) > 100000;
    if (att_ready) {
        uint32_t t_frame = hal_time_us();
        nav_pose_t at;
        int32_t r[3][3], tt[3];
        pose_query_t query = pose_at(&nt->pose, ft, &at);
        if (!pose_query_valid(query)) {
            g_app.n_time_skip++;
            if (query >= POSE_ATT_EMPTY) g_app.n_tq_att++; else g_app.n_tq_odo++;
        }
        if (!pose_query_valid(query)) at = nt->pose.cur; /* 仅用于消费废帧，不融合/匹配 */
        pose_lidar_tf(&nt->pose, &at, r, tt);
        hal_map_info_t mi;
        hal_map_info(&mi);
        uint16_t inv = mi.inv_res ? mi.inv_res : 1311;
        int32_t cx = (int32_t)(((int64_t)at.x * inv) >> 16);
        int32_t cy = (int32_t)(((int64_t)at.y * inv) >> 16);
        /* 姿态突变前后 200 ms 的帧：点云整体倾斜未知，融合会在远处造成大片假台阶。
         * 提交空高度带（zmin > zmax）——帧被消费、不写图、不提结构点，地形扫描照常进行 */
        /* 11-01：平衡车站立时一直晃，姿态新息动辄超过 1.5°，原来"突变前后 200 ms 的帧一律不用"会让匹配和建图整段停摆
         * （定位质量冻结不变）。现在这类帧照常做定位匹配，只是不写进高程图（finish_fusion 里拦），避免假台阶堵路。 */
        s_frame_unsettled = pose_att_unsettled(&nt->pose, ft, 200000);
        bool skip = !pose_query_valid(query) || (!APP_FLAT_FRAMES && s_frame_unsettled);
        /* 原地转向时一帧 100 ms 里车就转了 6–7°，点云带拖影，跟踪窗只有 ±1.4°：转向中和刚停的帧不匹配也不建图，
         * 航向这段只靠陀螺；转完头几帧放宽角度窗再接上 */
        bool turn_skip = prior && turn_recent && !skip && lc->st != LOC_ODOM;
        if (turn_skip) skip = true;
        bool no_lut = !lidar_cal_ready(&g_app.lcal);      /* 方向表只写了一部分：点的方向不可信 */
        bool matching = !skip && !no_lut && !receiving && (prior ? lc->st != LOC_ODOM : g_app.pm_cfg.enable);
        hal_lidar_stage(matching ? HAL_LIDAR_MATCH_ONLY : HAL_LIDAR_NORMAL);
        if (skip || no_lut) {
            hal_lidar_commit(r, tt, cx, cy, 1, 0,ft);
            if (no_lut) g_app.n_lut_skip++;
            else if (turn_skip) g_app.n_turn_skip++;
            else g_app.n_skip++;
            skip = true;
        } else {
            if (!matching) wait_anchor();
            if(!matching && !prior) {
                nav_pose_t local;
                local_frame_pose(&nt->terrain_frame,&at,&local);
                pose_lidar_tf(&nt->pose,&local,r,tt);
                cx=(int32_t)(((int64_t)local.x*inv)>>16);cy=(int32_t)(((int64_t)local.y*inv)>>16);
            }
            if (!matching && s_frame_unsettled) hal_lidar_commit(r, tt, cx, cy, 1, 0, at.t_us);
            else hal_lidar_commit(r, tt, cx, cy, at.z + g_app.zband_lo, at.z + g_app.zband_hi,at.t_us);
        }
        g_app.pm_pend = matching;
        g_app.fuse_held = matching;
        g_app.pm_at = at;
        g_app.pm_stale = false;
        g_app.n_frames++;
        tmax(&g_app.tmax_frame, t_frame);
    }
    uint32_t t_match = hal_time_us();
    /* 匹配：结构点就绪 -> 异步打分 -> 提案/门控/提交 -> 结构图更新及第二遍高度融合。 */
    const pm_cfg_t *pc = prior ? &g_app.pm_cfg_prior : &g_app.pm_cfg;
    if (g_app.pm_pend && hal_match_ready()) {
        g_app.pm_pend = false;
        g_app.pm_align = false;
        if (g_app.pm_stale || lc->st == LOC_LOST || (lc->st == LOC_ALIGN && g_app.turning)) {
            g_app.pm_k = 0;
        } else if (lc->st == LOC_ALIGN) {
            hal_match_gate(false);
            g_app.pm_k = loc_align_next(lc, g_app.pm_work.cand, PM_MAX_CAND);
            g_app.pm_align = true;
        } else {
            g_app.pm_wide = g_app.wide_left > 0;
            if (g_app.pm_wide) g_app.wide_left--;
            g_app.pm_k = pose_match_cands(track_cfg(pc), g_app.pm_work.cand);
        }
        if (g_app.pm_k > 0 && hal_match_start(g_app.pm_at.x, g_app.pm_at.y, g_app.pm_work.cand, g_app.pm_k))
            g_app.pm_run = true;
        else {
            hal_match_gate(true);
            app_match_update(0, 0, 0, g_app.pm_at.x, g_app.pm_at.y);
            finish_fusion(!g_app.pm_stale && (!prior || APP_FLAT_GROUND || lc->st == LOC_OK || lc->st == LOC_DEGRADED));
        }
    }
    if (g_app.pm_run && hal_match_result(g_app.pm_work.res, g_app.pm_k)) {
        g_app.pm_run = false;
        if (g_app.pm_stale) {
            hal_match_gate(true);
            app_match_update(0, 0, 0, g_app.pm_at.x, g_app.pm_at.y);
            finish_fusion(false);
        } else if (g_app.pm_align) {
            loc_align_feed_generated(lc, g_app.pm_work.res, g_app.pm_k);
            g_app.pm_k = loc_align_next(lc, g_app.pm_work.cand, PM_MAX_CAND);
            if (g_app.pm_k > 0 && hal_match_start(g_app.pm_at.x, g_app.pm_at.y, g_app.pm_work.cand, g_app.pm_k)) {
                g_app.pm_run = true;                 /* 同一帧的下一批候选 */
            } else {
                g_app.pm_align = false;
                hal_match_gate(true);
                bool jumped = loc_align_finish(lc, now);
                if (jumped) {
                    pm_stat_t correction = {.dx=lc->res_dx, .dy=lc->res_dy, .dyaw=lc->res_da};
                    if (g_app.pose_seeded) limit_aux_correction(&correction);
                    pose_match_commit(&nt->pose, g_app.pm_at.x, g_app.pm_at.y, &correction);
                    frame_jumped(nt);
                }
                if (lc->st == LOC_LOST) g_app.t_lost = now;
                app_match_update(0, 0, 0, g_app.pm_at.x, g_app.pm_at.y);
                /* 全局跳变后只释放旧帧，下一新帧使用新坐标；平地上没对准成功时按推算位姿照常写局部图，眼前障碍检查不断档 */
                finish_fusion(APP_FLAT_GROUND && !jumped);
            }
        } else {
            bool ok = pose_match_solve(track_cfg(pc), g_app.pm_work.res, g_app.pm_k, &g_app.pm);
            bool lost = prior && loc_track(lc, &g_app.pm, g_app.pm_work.res, ok, now);
#if APP_DR_PRIMARY
            /* During an active task retain conservative tracking. In IDLE,
             * restore the bounded recovery path instead of sticking at q=0. */
            if (lost && recover_idle_match(nt, lc, now)) ok = false;
            if (prior) ok = dr_gate(ok, g_app.pm_work.res);
#else
            if (lost) {
                /* 丢失：原地保持，以当前估计为中心重定位 */
                loc_start_align(lc, lc->cfg.reloc_mm, lc->cfg.reloc_ang);
                ok = false;
            }
#endif
            int32_t old_x = g_app.pm_at.x, old_y = g_app.pm_at.y;
            if (ok) {
                int64_t x=nt->pose.x_um,y=nt->pose.y_um;
                pose_match_commit(&nt->pose,old_x,old_y,&g_app.pm);
                if(!prior) local_frame_preserve(&nt->terrain_frame,x,y,nt->pose.x_um,nt->pose.y_um,g_app.pm.dyaw);
                if (prior && lc->st == LOC_OK) pose_bias_feedback(&nt->pose, g_app.pm.dyaw, g_app.pm_at.t_us);
            }
            app_match_update(ok ? g_app.pm.dx : 0, ok ? g_app.pm.dy : 0, ok ? g_app.pm.dyaw : 0,
                             old_x, old_y);
            if (ok) {
                g_app.pm_at.x += g_app.pm.dx; g_app.pm_at.y += g_app.pm.dy;
                g_app.pm_at.yaw = (angle_t)(g_app.pm_at.yaw + g_app.pm.dyaw);
            }
            finish_fusion(!prior || lc->st == LOC_OK || lc->st == LOC_DEGRADED);
        }
    }
    tmax(&g_app.tmax_match, t_match);
    if (prior && lc->st != LOC_OK && lc->st != LOC_DEGRADED) pose_bias_feedback_reset(&nt->pose);
    /* 定位状态只在处理到帧时更新：帧全被丢时会一直停在"正常"。正常却 1.5 s 没有可用帧（转向期间除外）就降为退化 */
    if (prior && lc->st == LOC_OK && !turn_recent && (uint32_t)(now - lc->t_info) > APP_LOC_BLIND_US &&
        (uint32_t)(now - g_app.t_turn_end) > APP_LOC_BLIND_US) {
        lc->st = LOC_DEGRADED;
        lc->degr_since = now;
    }
    /* Automatic turning was disabled on 11-01. Do not leave its 1.8 s
     * synthetic turning flag active: that suppresses fresh alignment frames
     * while the robot is actually holding still. */
    lc->want_turn = false;
    g_app.turning = false;
    nt->hold_wz = 0; /* 11-01 用户要求：对准失败不转向，原地等下一帧重试 */
    /* 丢失（对准重试用尽）：每 3 s 再试一次 */
    if (prior && lc->st == LOC_LOST && (uint32_t)(now - g_app.t_lost) > 3000000)
        loc_start_align(lc, lc->cfg.reloc_mm, lc->cfg.reloc_ang);

    /* 4. 主机报文（包括已取消搜索保留的原报文）。 */
    uint32_t t_host = hal_time_us();
    drain_host_messages(4u);
    tmax(&g_app.tmax_host, t_host);

    apply_host_link_lock(hal_time_us());
    /* 5. Separate the initial coordinate reference from lidar confidence. */
    apply_pose_policy(nt, prior);
    if ((uint32_t)(now - g_app.t_plan) >= APP_PLAN_PERIOD_US) {
        g_app.t_plan += APP_PLAN_PERIOD_US;
        if ((uint32_t)(now - g_app.t_plan) >= APP_PLAN_PERIOD_US) g_app.t_plan = now;   /* 落后太多：重新对齐 */
        g_nav_search_interrupted=false;
        imu_pump();
        gmap_set_live(&nt->gm, g_app.n_dr_acc && now - g_app.t_dr_last < APP_LIVE_US);
        uint32_t t_step = hal_time_us();
        nav_task_step(nt, now);
        tmax(&g_app.tmax_step, t_step);
        imu_pump();
    } else {
        uint32_t t_map = hal_time_us();
        nav_task_map_work(nt,4);
        nav_task_plan_work(nt);
        tmax(&g_app.tmax_map, t_map);
    }

    /* At most one checkpoint payload is pending. Process exactly that head;
     * leave newly queued frames for the next poll instead of draining again. */
    if(host_pending_len) drain_host_messages(1u);
    apply_host_link_lock(hal_time_us());
    /* 6. 状态回传 */
    /* Never overwrite a retained raw payload with telemetry construction. */
    if (!host_pending_len && (uint32_t)(now - g_app.t_status) >= APP_STATUS_PERIOD_US) {
        g_app.t_status = now;
        proto_status_t s;
        nav_task_status(nt, &s, now);
        s.loc_state = reported_loc_state(prior);
        s.loc_quality = (uint8_t)(prior ? loc_quality(lc) : 0);
        int n = proto_build_status(host_rx_buf, &s);
        hal_host_send(host_rx_buf, n);
    }
}
