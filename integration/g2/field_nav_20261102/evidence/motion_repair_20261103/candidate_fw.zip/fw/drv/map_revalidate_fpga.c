/* Board HAL for the staged RCV1 window; old bitstreams fail closed. */
#include "map_revalidate.h"
#include "hal.h"
#include "nav_regs_map.h"
#ifndef NAV_BASE
#define NAV_BASE 0x40000000u
#endif
static inline uint32_t rd(uint32_t off){return *(volatile uint32_t *)(uintptr_t)(NAV_BASE+off);}
static inline void wr(uint32_t off,uint32_t v){*(volatile uint32_t *)(uintptr_t)(NAV_BASE+off)=v;}
static uint32_t capture;
bool hal_clear_depth_begin(uint32_t cap){
 if(rd(0xD200)!=0x52435631u || !(rd(NAV_LIDAR_POSE_STAT)&NAV_LIDAR_POSE_STAT_WAITING_MASK) || rd(0xD20C)!=cap)return false;
 capture=cap;return true;
}
uint16_t hal_clear_depth_pixel(int u,int v){
 if(u<0 || u>=160 || v<0 || v>=60 || rd(0xD20C)!=capture)return 0;
 wr(0xD204,(uint32_t)(v*160+u));uint32_t q=rd(0xD208);
 return q&0x10000u?(uint16_t)q:0;
}
bool hal_clear_read(int32_t gx,int32_t gy,rc_cell_t *out){
 hal_map_info_t a,b;hal_support_t s;
 if(!hal_map_info(&a) || !a.inv_res)return false;
 int32_t x,y;nav_win_to_mm(&a,gx-a.cx+NP_MAP_N/2,gy-a.cy+NP_MAP_N/2,&x,&y);
 if(!hal_map_support(x,y,&s))return false;
 uint8_t fc=(uint8_t)rd(NAV_MAP_FRAME_CNT);
 if(!hal_map_info(&b) || a.seq!=b.seq || a.cx!=b.cx || a.cy!=b.cy)return false;
 uint8_t tag=(uint8_t)((((uint32_t)(gy>>7)&15)<<4)|((uint32_t)(gx>>7)&15));
 *out=(rc_cell_t){gx,gy,s.lo,s.hi,tag,(uint8_t)(fc-s.age),s.count,s.age};return true;
}
bool hal_clear_drop(const rc_cell_t *c){
 if(rd(0xD20C)!=capture)return false;
 wr(0xD210,((uint32_t)c->stamp<<12)|((uint32_t)c->tag<<4)|c->count);
 wr(0xD214,(((uint32_t)c->gy&127)<<7)|((uint32_t)c->gx&127));
 wr(0xD218,1);return (rd(0xD218)&0x80000001u)==0x80000001u;
}
