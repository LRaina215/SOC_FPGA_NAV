/* 位姿估计与雷达外参合成。
 * 预测：底盘里程计（vx, vy, wz）三维积分——前进速度按 IMU 俯仰分解为水平位移和高度变化；
 *       IMU 给俯仰/横滚（航向可选）。
 * 修正：pose_match（点云与局部高程图区间一致性匹配）给出 dx/dy/dyaw/dz，经 pose_correct_delta() 施加。
 * XY历史约620ms、姿态约630ms，用于按采集时刻对齐雷达与RK3588目标。
 */
#ifndef NAV_POSE_H
#define NAV_POSE_H

#include "nav_types.h"
#include "fixmath.h"

#define POSE_HIST 32
#define POSE_ATT_HIST 64           /* 姿态历史（按 IMU 频率，100 Hz 时 0.64 s）：雷达帧时刻的俯仰/横滚插值 */
#define POSE_ATT_JUMP (16 * 273)     /* 姿态新息超过 1.5°（angle×16）视为突变 */
#define POSE_HIST_PERIOD_US 20000u   /* 积分频率不决定历史窗口：32项620ms；ATT为64项630ms */
#define POSE_PREDICT_US 60000u       /* 里程计最多外推 60 ms（主循环不再卡 100 ms 后不需要更宽） */
#define POSE_BIAS_WIN_US 10000000u   /* 静止零偏估计窗口：盖住站立时车头秒级的来回摆 */
#define POSE_BIAS_MAX 20             /* 零偏估计上限 mrad/s（控制核开机已扣过零偏，这里只修残余） */
typedef enum { POSE_OK, POSE_PREDICTED, POSE_EMPTY, POSE_OLD, POSE_FUTURE,
               POSE_ATT_EMPTY, POSE_ATT_OLD, POSE_ATT_FUTURE } pose_query_t;
typedef struct { int32_t x, y, z; uint32_t t_us; angle_t yaw; } pose_xy_hist_t;
static inline bool pose_query_valid(pose_query_t q) { return q <= POSE_PREDICTED; }

typedef struct {
    nav_pose_t cur;
    /* 亚毫米累计，避免积分截断误差 */
    int64_t    x_um, y_um, z_um;
    int64_t travel_um;
    int64_t    yaw_rem;        /* 陀螺积分除法余数，避免每个高频样本都丢失小角度 */
    /* 控制核已扣启动零偏；这里仅按可靠地图匹配估残余，零导航指令不代表静止 */
    int32_t    wz_bias_q8;      /* mrad/s × 256 */
    uint32_t   still_us;       /* 当前零偏窗口已累计的时间 */
    bool       bias_valid;
    uint32_t   bias_n;         /* 已用于零偏估计的窗口数（每窗 1/4 跟踪） */
    int32_t    pitch_f, roll_f;  /* 俯仰/横滚 α-β 滤波状态（angle × 16） */
    int32_t    pitch_r, roll_r;  /* 角速度估计（angle × 16 / 20 ms） */
    uint32_t   att_jump_us;      /* 最近一次姿态突变时刻 */
    bool       att_jumped;
    uint32_t   att_n;          /* 已收姿态帧数 */
    bool       cmd_still;       /* 当前下发的速度指令为零（由导航任务设置）：只有指令为零时才做零偏估计 */
    uint32_t   last_odo_us;
    int16_t    odo_vx, odo_vy, odo_wz; /* 最近实际反馈，用于停稳判定；不使用下发指令代替 */
    bool       have_odo;
    bool       imu_att_valid;   /* IMU 航向有效（用 IMU 航向代替陀螺积分） */
    bool       have_att;        /* 收到过姿态 */
    uint32_t   imu_t_us;
    pose_xy_hist_t hist[POSE_HIST]; /* 姿态另有独立历史，不重复占SRAM */
    int        hist_head, hist_n;
    struct { uint32_t t_us; int16_t pitch, roll; } att_hist[POSE_ATT_HIST];
    int        att_head, att_hn;
    int32_t    gyro_pr, gyro_rr;  /* 陀螺俯仰/横滚角速度（angle × 16 / 20 ms） */
    uint32_t   gyro_t_us;
    bool       have_gyro;
    bool       decomp_pitch;    /* 前进速度按 IMU 俯仰分解出高度变化：四轮 / 履带底盘为真；
                                   两轮自平衡车机身俯仰是平衡姿态而不是坡度，为假（高度只靠地图锚定） */
    /* 雷达安装外参：机身系 */
    fx_mat3_t  r_bs;
    int32_t    t_bs[3];
    /* 旧零指令窗口字段保留；当前不从它估零偏。另存可靠雷达航向修正累计。 */
    int32_t    zw_sum, zv_sum;
    uint32_t   zw_n;
    int32_t    fb_sum;
    uint32_t   fb_t0;
    bool       fb_on;
} pose_est_t;

void pose_init(pose_est_t *p, angle_t mount_pitch, int32_t mount_x_mm, int32_t mount_z_mm);
/* 底盘速度回传，积分到当前位姿 */
void pose_odom(pose_est_t *p, int16_t vx, int16_t vy, int16_t wz, uint32_t t_us);
/* IMU 姿态（绝对航向可选）。yaw_valid=false 时只用俯仰横滚 */
void pose_imu_att(pose_est_t *p, angle_t yaw, angle_t pitch, angle_t roll, bool yaw_valid, uint32_t t_us);
/* IMU 角速度（原始 ×2000/32768 °/s，机身系）：有新鲜角速度时，俯仰/横滚用它做预测（陀螺辅助互补滤波），
 * 自平衡车持续摆动时没有 α-β 的跟踪滞后 */
void pose_imu_gyro(pose_est_t *p, int16_t gx, int16_t gy, uint32_t t_us);
/* t_us 之前 win_us 内发生过姿态突变 */
bool pose_att_unsettled(const pose_est_t *p, uint32_t t_us, uint32_t win_us);
/* 外部定位修正（预留） */
void pose_correct(pose_est_t *p, int32_t x, int32_t y, angle_t yaw);
/* 把位姿（连同历史）整体刚体变换到 (x, y, yaw)：进入地图系 / 重置原点。z 不变 */
void pose_set(pose_est_t *p, int32_t x, int32_t y, angle_t yaw);
/* 增量修正（匹配定位用），同时修正位姿历史，使随后的历史查询一致 */
void pose_correct_delta(pose_est_t *p, int32_t dx, int32_t dy, int32_t dz, int32_t dyaw);
/* 雷达匹配接受的航向修正 dyaw（angle）：连续跟踪 3 s 以上的累计修正量折算成残余陀螺零偏并扣除。
 * 转向或定位中断时调 pose_bias_feedback_reset 重新开窗。 */
void pose_bias_feedback(pose_est_t *p, int32_t dyaw, uint32_t t_us);
void pose_bias_feedback_reset(pose_est_t *p);
/* 无效查询不返回可用位姿；所有比较按32位时间回绕。XY预测有明确上限（POSE_PREDICT_US）。 */
pose_query_t pose_xy_at(const pose_est_t *p, uint32_t t_us, nav_pose_t *out);
pose_query_t pose_at(const pose_est_t *p, uint32_t t_us, nav_pose_t *out);
/* 合成 雷达->里程计 变换（寄存器格式） */
void pose_lidar_tf(const pose_est_t *p, const nav_pose_t *at, int32_t r_q14[3][3], int32_t t_mm[3]);
/* 足迹高度锚定：机器人轮下栅格（此前已观测、现处盲区）的地面高度就是机器人应有的高度。
 * 用它把位姿 z 拉向地图，消除里程计高度积分漂移造成的"新旧观测高差"（假台阶）。 */
void pose_anchor_z(pose_est_t *p, int32_t half_len_mm, int32_t half_wid_mm, int32_t gain_q8);
void pose_anchor_z_at(pose_est_t *p,const nav_pose_t *at,int32_t hl,int32_t hw,int32_t gain_q8);
/* 机身系点 -> 里程计系点 */
void pose_body_to_odom(const nav_pose_t *at, int32_t bx, int32_t by, int32_t *ox, int32_t *oy);

#endif
