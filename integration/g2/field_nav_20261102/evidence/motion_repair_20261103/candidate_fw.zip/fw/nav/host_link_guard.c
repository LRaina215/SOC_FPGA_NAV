#include "host_link_guard.h"
host_link_guard_t g_host_link_guard;
void host_link_guard_init(host_link_guard_t *g,uint32_t now) { *g=(host_link_guard_t){.locked_since_us=now,.locked=true}; }
#ifndef APP_HOST_LINK_TIMEOUT
#define APP_HOST_LINK_TIMEOUT 0   /* 11-01 用户要求删掉通信超时急停：目标在 FPGA 上自主执行，RK 断开不影响；急停只来自主机显式 ESTOP */
#endif
bool host_link_guard_poll(host_link_guard_t *g,uint32_t now)
{
    if(APP_HOST_LINK_TIMEOUT && g->have_rx && (uint32_t)(now-g->last_rx_us)>=HOST_LINK_TIMEOUT_US) {
        if(!g->timed_out) {g->timeouts++;g->locked_since_us=now;}
        g->locked=true;g->timed_out=true;
    }
    return g->locked;
}
bool host_link_guard_observe(host_link_guard_t *g,const proto_msg_t *m,uint32_t now,uint32_t rx_us)
{
    bool motion=false,clear=false;
    switch(m->type) {
    case MSG_GOAL: motion=true;break;
    case MSG_WAYPOINTS: motion=m->u.wp.n!=0;break;
    case MSG_TARGET: motion=m->u.target.found!=0;break;
    case MSG_MODE:
        if(m->u.mode.mode>NAV_MODE_ESTOP) {host_link_guard_poll(g,now);g->rejected++;return false;}
        clear=m->u.mode.mode==NAV_MODE_IDLE;
        motion=m->u.mode.mode>=NAV_MODE_GOTO && m->u.mode.mode<=NAV_MODE_SEARCH;
        break;
    case MSG_SET_POSE: case MSG_MAP_BEGIN: case MSG_MAP_DATA: case MSG_MAP_END: case MSG_MAP_CLEAR: case MSG_SLF_CONFIG: break;
    default:host_link_guard_poll(g,now);g->rejected++;return false;
    }
    /* Future/too-old packets and regressing queued arrival times cannot renew. */
    if((APP_HOST_LINK_TIMEOUT && (uint32_t)(now-rx_us)>=HOST_LINK_TIMEOUT_US) ||
       (g->have_rx && (uint32_t)(now-g->last_rx_us)<HOST_LINK_TIMEOUT_US &&
        (int32_t)(rx_us-g->last_rx_us)<0)) {host_link_guard_poll(g,now);g->rejected++;return false;}
    /* A fresh queued arrival inside an uninterrupted lease precedes this poll.
     * Never heal an already latched timeout or a real arrival gap>=250ms. */
    bool continuous=g->have_rx && !g->locked && !g->timed_out &&
        (int32_t)(rx_us-g->last_rx_us)>=0 && (uint32_t)(rx_us-g->last_rx_us)<HOST_LINK_TIMEOUT_US;
    if(continuous) g->last_rx_us=rx_us;
    host_link_guard_poll(g,now);
    g->have_rx=true;g->last_rx_us=rx_us;
    /* An idle queued BEFORE this lock cannot authorize recovery. */
    if(clear && (uint32_t)(now-rx_us)<=(uint32_t)(now-g->locked_since_us)) {g->locked=false;g->timed_out=false;}
    if(g->locked && motion) {g->rejected++;return false;}
    g->accepted++;return true;
}
void host_link_guard_filter(host_link_guard_t *g,uint32_t now,nav_cmd_t *cmd)
{
    if(host_link_guard_poll(g,now)) {
        cmd->vx=cmd->vy=cmd->wz=0;
        /* Mode is status only; zero numeric targets implement the stop request. */
        cmd->mode=g->timed_out?NAV_MODE_ESTOP:NAV_MODE_IDLE;
    }
}
