/* IMU 串口协议解析（可替换）。
 * 硬件只提供原始字节 + 突发时间戳，协议全部在这里实现；换 IMU 型号只改本文件。
 * IMU088 的协议文档尚未拿到，这里先实现常见的 0x55 帧协议（WIT 维特智能系列：
 * 0x55 0x53 + roll/pitch/yaw 各 int16（×180/32768 度）+ 温度 + 校验和；
 * 0x55 0x52 + wx/wy/wz 各 int16（×2000/32768 °/s）角速度帧）作为样例。
 * 拿到 IMU088 手册后：新增一个 imu_proto_t 分支即可，接口不变。
 */
#ifndef NAV_IMU_PARSE_H
#define NAV_IMU_PARSE_H

#include "nav_types.h"

/* IMU_PROTO_BMI_INTERNAL：整车镜像里控制侧 BMI088 融合结果经片内串口送来（g2_top 的 bmi_att_uart）：
 * 0x55 0x5B 重力单位向量（控制机身系 Q12）+ 融合序号，0x55 0x5C 角速度（控制机身系 Q9 rad/s）。
 * 控制机身系 X 右、Y 前、Z 上；导航机身系 X 前、Y 左、Z 上；换算见 imu_parse.c 的 IMU_BMI_* 宏（须装车核对）。 */
typedef enum { IMU_PROTO_WIT55 = 0, IMU_PROTO_BMI_INTERNAL = 1 } imu_proto_t;

typedef struct {
    imu_proto_t proto;
    uint8_t  buf[16];
    int      n;
    uint32_t t_burst;           /* 当前突发首字节时间 */
    /* 输出 */
    bool     att_new;
    angle_t  roll, pitch, yaw;
    uint32_t att_t_us;
    bool     gyro_new;
    int16_t  gx, gy, gz;        /* 原始角速度（×2000/32768 °/s），机身系 x 前 y 左 z 上 */
    uint32_t gyro_t_us;
    uint32_t n_ok, n_bad;
    uint16_t bmi_seq;           /* BMI 内部协议：最近一帧重力帧的融合序号 */
} imu_parser_t;

void imu_parser_init(imu_parser_t *p, imu_proto_t proto);
/* 喂一个字节；返回 true 表示解析出新的姿态（角速度帧只置 gyro_new，返回 false） */
bool imu_parser_feed(imu_parser_t *p, uint8_t b, bool first, uint32_t t_us);

#endif
