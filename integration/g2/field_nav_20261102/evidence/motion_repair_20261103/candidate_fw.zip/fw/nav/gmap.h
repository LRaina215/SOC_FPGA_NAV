/* 全局记忆栅格（软核）：把 FPGA 局部代价图（5 cm、6.4 m 窗口、数秒过期）累积成大范围粗栅格，供 A* 使用。
 *
 * 为什么需要：局部图只覆盖 6.4 m 且未观测区会过期，A* 只在局部图上规划时，
 * 长障碍（路沿、墙）的另一端一旦出窗或过期就被"忘掉"，路径在两侧来回翻转，机器人原地打转（闭环仿真实测）。
 *
 * 格子：GM_DS×GM_DS 个局部格合为一格（默认 2 → 10 cm），GM_N×GM_N（默认 64 → 6.4 m，按 5 m 场地），
 * 机器人离边界不足 1/4 边长时整体平移半个边长（滚动）。
 * 每格：occ 证据计数（有致命格 +2，无致命格 -1，饱和）+ 最近一次的可通行代价上限。
 * 局部图里未知的格不改动记忆——看不到的障碍不会被遗忘，只有再次看到"可通行"才会被清除。
 *
 * 有图模式：先验代价图（离线由整张地图算出）作为静态层，栅格原点固定为先验图原点、不再滚动。
 * 合成（GM_PRIOR_LIVE）：先验层原样保留，实时观测只能在先验墙之外"加"障碍，规则见 gmap.c。
 */
#ifndef NAV_GMAP_H
#define NAV_GMAP_H

#include "nav_types.h"
#include "hal.h"

#ifndef GM_N
#define GM_N 64
#endif
#ifndef GM_DS
#define GM_DS 2
#endif
#define GM_VBLK 4
#define GM_COST_PARTIAL 252      /* 仅记忆粗格：部分细格受限，须细图复核 */
#define GM_COST_BLOCKED 253      /* 整粗格受限 */

typedef struct {
    int8_t  occ_hit, occ_miss, occ_max, occ_min;   /* 证据增量与饱和 */
    int8_t  occ_thr;                                /* occ >= thr 视为致命 */
    uint8_t min_known;                              /* 一格内至少这么多已知局部格才更新 */
} gmap_cfg_t;

typedef struct {
    gmap_cfg_t cfg;
    int32_t ox, oy;                 /* 栅格 (0,0) 对应的局部格索引 / GM_DS（绝对粗格坐标） */
    bool    init;
    int8_t  occ[GM_N * GM_N];       /* -128 = 未观测 */
    uint8_t cost[GM_N * GM_N];      /* 0..200地形/252部分受限/253全受限，不等同原始占用 */
    uint8_t grid[GM_N * GM_N];      /* A*栅格：255未知、254占用、253禁行、252高代价 */
    uint8_t prior[GM_N * GM_N];     /* 先验代价（有图模式；255 = 无） */
    struct { int16_t gx, gy; uint8_t r; uint16_t ttl; } vblk[GM_VBLK];   /* 临时虚拟障碍（反复卡住处），ttl 按更新次数 */
    bool    has_prior;
    int32_t pox, poy;               /* 下载中的先验图原点 / 宽 */
    int     pgnx;
    uint32_t n_upd, n_shift;
    int32_t rcx, rcy;               /* 本次更新时机器人所在粗格（绝对坐标） */
    uint16_t n_live;                /* 有图模式：进入规划栅格的实时障碍格数（诊断） */
    bool    live_on;                /* 雷达修正近期有效：实时障碍才加证据、进规划栅格 */
    uint16_t row_seq[GM_N],work_seq,work_row;
    bool work_active,work_done,ready;
} gmap_t;

void gmap_default_cfg(gmap_cfg_t *c);
void gmap_init(gmap_t *g);
/* 开关实时障碍层；状态变了就重新合成规划栅格、让已有路径失效 */
void gmap_set_live(gmap_t *g, bool on);
/* map: 局部代价图窗口（hal_map_copy 输出），mi: 其窗口信息；rx/ry: 机器人位置 mm */
void gmap_update(gmap_t *g, const uint8_t *map, const hal_map_info_t *mi, int32_t rx, int32_t ry);
/* 有界后台更新：每次最多rows行，同一行同一代仅积累一次证据。
 * 跨帧可能为不同观测年龄的记忆拼图，只作引导，运动仍用当前细图复核。 */
bool gmap_update_rows(gmap_t *g,const uint8_t *map,const hal_map_info_t *mi,int32_t rx,int32_t ry,int rows);
/* 有图模式：先验层。begin 固定原点并清空；put 按先验图行优先下标写一格；done 生效 */
void gmap_prior_begin(gmap_t *g, int32_t gox, int32_t goy, int gnx, int gny);
void gmap_prior_put(gmap_t *g, int i, uint8_t v);
void gmap_prior_done(gmap_t *g);
void gmap_prior_drop(gmap_t *g);
/* 临时虚拟障碍：在 (x, y) mm 周围 r 格标为致命，保持 ttl 次更新。用于"规划说能过、局部规划过不去"的死锁：
 * 同一处反复卡住时把那里堵上，A* 换路 */
void gmap_block_add(gmap_t *g, const hal_map_info_t *mi, int32_t x, int32_t y, int r, int ttl);
/* 清掉观测层（位姿跳变到地图系后，旧坐标系下的观测作废），先验层保留 */
void gmap_clear_obs(gmap_t *g);
/* 坐标换算：mm <-> 栅格坐标（mi 提供分辨率） */
void gmap_mm_to_cell(const gmap_t *g, const hal_map_info_t *mi, int32_t x, int32_t y, int *gx, int *gy);
void gmap_cell_to_mm(const gmap_t *g, const hal_map_info_t *mi, int gx, int gy, int32_t *x, int32_t *y);

#endif
