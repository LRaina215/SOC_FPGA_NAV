#ifndef NAV_SEARCH_CHECKPOINT_H
#define NAV_SEARCH_CHECKPOINT_H
#include <stdbool.h>
extern bool g_nav_search_interrupted;
bool nav_app_search_checkpoint(void);
#endif
