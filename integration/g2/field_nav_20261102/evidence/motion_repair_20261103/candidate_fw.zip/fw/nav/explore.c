#include "nav_search_checkpoint.h"
#include "explore.h"
#include "scratch.h"
#include "fixmath.h"
#include "nav_params.h"

/* 有图搜索时相机"看过"的距离：要取视觉实际能稳定认出目标的距离。取大了，远处只是进了视野、其实没认出来的
 * 区域也被记成看过，之后不会再去（仿真：实际只能认 1.5 m 而这里按 4 m 记时，车后 0.8 m 的目标 150 s 没找到）。 */
#ifndef EXP_CAM_RANGE_MM
#define EXP_CAM_RANGE_MM 4000
#endif

void explore_default_cfg(explore_cfg_t *c)
{
    c->w_clear = 10;
    c->w_unknown = 6;
    c->w_trav = 1;
    c->w_slope = 1;
    c->w_visited = 8;
    c->max_range_cells = 40;
    c->block = 253;
    c->min_goal_mm = 600;
    c->frontier_min_mm = 1000;
    c->cam_fov = 12743;             /* 70° */
    c->cam_range_mm = EXP_CAM_RANGE_MM;
    c->clear_cells = 0;
}

void explore_init(explore_t *e)
{
    for (int i = 0; i < EXP_VIS_N * EXP_VIS_N; i++) e->visited[i] = 0;
    e->best = -1;
    explore_seen_reset(e);
}

void explore_seen_reset(explore_t *e)
{
    for (unsigned i = 0; i < sizeof e->seen_bits; i++) e->seen_bits[i] = 0;
    e->n_seen = 0;
    e->n_seen_reset++;
}

/* 可被搜索的格：先验/观测已知且可走 */
static bool searchable(uint8_t v) { return v <= NP_COST_FREE_MAX; }

void explore_seen_mark(explore_t *e, const explore_cfg_t *c, const gmap_t *gm, const hal_map_info_t *mi,
                       const nav_pose_t *pose)
{
    int32_t cell_mm = (int32_t)((int64_t)GM_DS * 65536 / (mi->inv_res ? mi->inv_res : 1311));
    int steps = c->cam_range_mm / (cell_mm / 2);
    const int NR = 24;
    for (int r = 0; r <= NR; r++) {
        angle_t a = (angle_t)(pose->yaw - c->cam_fov / 2 + (int32_t)((int64_t)c->cam_fov * r / NR));
        int32_t ca = fx_cos(a), sa = fx_sin(a);
        for (int s = 0; s <= steps; s++) {
            int32_t d = s * (cell_mm / 2);
            int gx, gy;
            gmap_mm_to_cell(gm, mi, pose->x + (int32_t)((int64_t)ca * d / Q14), pose->y + (int32_t)((int64_t)sa * d / Q14), &gx, &gy);
            if (gx < 0 || gy < 0 || gx >= GM_N || gy >= GM_N) break;
            int i = gy * GM_N + gx;
            if (!explore_seen_get(e,i)) { e->seen_bits[i>>3] |= (uint8_t)(1u<<(i&7)); e->n_seen++; }
            if (gm->grid[i] == NP_COST_LETHAL) break;          /* 视线被挡 */
        }
    }
}

static int vis_idx(int32_t x, int32_t y)
{
    int32_t cx = x >= 0 ? x / EXP_VIS_CELL_MM : (x - EXP_VIS_CELL_MM + 1) / EXP_VIS_CELL_MM;
    int32_t cy = y >= 0 ? y / EXP_VIS_CELL_MM : (y - EXP_VIS_CELL_MM + 1) / EXP_VIS_CELL_MM;
    return (int)(((uint32_t)cy & (EXP_VIS_N - 1)) * EXP_VIS_N + ((uint32_t)cx & (EXP_VIS_N - 1)));
}

void explore_mark(explore_t *e, const nav_pose_t *pose)
{
    int i = vis_idx(pose->x, pose->y);
    if (e->visited[i] < 255) e->visited[i]++;
}

bool explore_pick(explore_t *e, const explore_cfg_t *c, const uint8_t *map, const hal_map_info_t *mi,
                  const nav_pose_t *pose, int32_t *gx, int32_t *gy)
{
    const int N = HAL_MAP_N;
    /* 机器人在窗口中的位置（栅格） */
    int32_t rx = (int32_t)(((int64_t)pose->x * mi->inv_res) >> 16) - (mi->cx - N / 2);
    int32_t ry = (int32_t)(((int64_t)pose->y * mi->inv_res) >> 16) - (mi->cy - N / 2);
    e->best = -1;
    int32_t best = INT32_MIN;
    for (int d = 0; d < EXP_DIRS; d++) {
        angle_t a = (angle_t)(d * (65536 / EXP_DIRS));
        int32_t ca = fx_cos(a), sa = fx_sin(a);
        int clear = 0, unknown = 0, known = 0, maxc = 0;
        int32_t sumc = 0;
        bool hit = false;
        for (int s = 1; s <= c->max_range_cells; s++) {
            int32_t x = rx + (ca * s + Q14 / 2) / Q14;
            int32_t y = ry + (sa * s + Q14 / 2) / Q14;
            if (x < 0 || y < 0 || x >= N || y >= N) { unknown += c->max_range_cells - s + 1; break; }
            uint8_t v = map[y * N + x];
            if (v == 255) { unknown++; continue; }
            if (v >= c->block) { hit = true; break; }
            if (!hit) clear = s;
            known++;
            sumc += v;
            if (v > maxc) maxc = v;
        }
        e->clear[d] = clear;
        int32_t avg = known ? sumc / known : 0;
        /* 方向末端的访问热度 */
        int32_t clear_mm = (int32_t)((int64_t)clear * 65536 / mi->inv_res);
        int32_t ex_mm = pose->x + (int32_t)((int64_t)ca * clear_mm / Q14);
        int32_t ey_mm = pose->y + (int32_t)((int64_t)sa * clear_mm / Q14);
        int32_t vis = e->visited[vis_idx(ex_mm, ey_mm)];
        int32_t sc = c->w_clear * clear + c->w_unknown * unknown + c->w_trav * (200 - avg) / 10
                   - c->w_slope * maxc / 10 - c->w_visited * vis;
        e->score[d] = sc;
        /* 目标太近（前方就是障碍）的方向不选 */
        int32_t dist_mm = (int32_t)((int64_t)clear * 65536 / mi->inv_res);
        if (dist_mm < c->min_goal_mm && unknown == 0) continue;
        if (sc > best) { best = sc; e->best = d; }
    }
    if (e->best < 0) return false;
    angle_t a = (angle_t)(e->best * (65536 / EXP_DIRS));
    /* 目标取可通行距离的 80%，至少 min_goal */
    int32_t dist_mm = (int32_t)((int64_t)e->clear[e->best] * 65536 / mi->inv_res * 8 / 10);
    if (dist_mm < c->min_goal_mm) dist_mm = c->min_goal_mm;
    *gx = pose->x + (int32_t)((int64_t)fx_cos(a) * dist_mm / Q14);
    *gy = pose->y + (int32_t)((int64_t)fx_sin(a) * dist_mm / Q14);
    return true;
}

void explore_blacklist(explore_t *e, int32_t x, int32_t y)
{
    e->bl_x[e->bl_i] = x;
    e->bl_y[e->bl_i] = y;
    e->bl_i = (e->bl_i + 1) % EXP_BL;
    if (e->bl_n < EXP_BL) e->bl_n++;
}

/* 广度优先距离（格，0xFFFF = 未到达）与队列：在 g_scratch 里，与 A* 共用（scratch.h） */
#define s_bd (g_scratch.bfs.bd)
#define s_bq (g_scratch.bfs.bq)

/* Fast domain guarantees the original signed arithmetic and result are
 * representable. Outside it retain the original expression,including its
 * implementation-specific/extreme-input behavior;do not change global flags. */
static bool blacklist_within_1000(int32_t fx,int32_t fy,int32_t bx,int32_t by)
{
    int64_t dx=(int64_t)fx-bx,dy=(int64_t)fy-by;
    const int64_t bound=(int64_t)1<<30;
    if(dx>=-bound && dx<=bound && dy>=-bound && dy<=bound) {
        if(dx<=-1000 || dx>=1000 || dy<=-1000 || dy>=1000) return false;
        int32_t x=(int32_t)dx,y=(int32_t)dy;
        return x*x+y*y<1000000;
    }
    return fx_dist(fx-bx,fy-by)<1000;
}

bool explore_frontier(explore_t *e, const explore_cfg_t *c, const gmap_t *gm, const hal_map_info_t *mi,
                      const nav_pose_t *pose, bool seen_mode, int32_t *gx, int32_t *gy)
{
    astar_cancel(); /* BFS与分周期A*复用缓存，切换前显式取消旧搜索 */
    if(!nav_app_search_checkpoint()) return false;
    static const int8_t DX4[4] = {1, -1, 0, 0}, DY4[4] = {0, 0, 1, -1};
    int rx, ry;
    gmap_mm_to_cell(gm, mi, pose->x, pose->y, &rx, &ry);
    e->n_frontier = 0;
    if (rx < 0 || ry < 0 || rx >= GM_N || ry >= GM_N) return false;
    for(int first=0;first<GM_N*GM_N;first+=256) {
        int end=nav_min32(first+256,GM_N*GM_N);
        for(int i=first;i<end;i++) {
            s_bd[i]=0xFFFF;
            /* 车过不去的格（A* 也不走）：离致命格不足 clear_cells 格，标 0xFFFE，不展开。
             * 11-02 地图 2 找物仿真：不看车宽时会选到 0.5 m 窄条、死胡同角上的点，车原地等 12 s 才换点 */
            int x=i%GM_N,y=i/GM_N,r=c->clear_cells-1;
            for(int yy=y-r;r>0 && yy<=y+r && s_bd[i]==0xFFFF;yy++)
                for(int xx=x-r;xx<=x+r;xx++)
                    if(xx>=0 && yy>=0 && xx<GM_N && yy<GM_N && gm->grid[yy*GM_N+xx]==NP_COST_LETHAL) {s_bd[i]=0xFFFE;break;}
        }
        if(!nav_app_search_checkpoint()) return false;
    }
    int qh = 0, qt = 0;
    s_bd[ry * GM_N + rx] = 0;
    s_bq[qt++] = (uint16_t)(ry * GM_N + rx);
    int best = -1;
    int32_t best_cost = INT32_MAX;
    /* 目标至少离开 min_goal（格） */
    int32_t cell_mm = (int32_t)((int64_t)GM_DS * 65536 / (mi->inv_res ? mi->inv_res : 1311));
    int32_t min_cells = c->min_goal_mm / cell_mm + 1;
    while (qh < qt) {
        if((qh&31)==0 && !nav_app_search_checkpoint()) return false;
        int i = s_bq[qh++];
        int x = i % GM_N, y = i / GM_N;
        uint16_t d = s_bd[i];
        /* 是否边界格 */
        bool frontier = false;
        for (int k = 0; k < 4; k++) {
            int nx = x + DX4[k], ny = y + DY4[k];
            if (nx < 0 || ny < 0 || nx >= GM_N || ny >= GM_N) continue;
            uint8_t v = gm->grid[ny * GM_N + nx];
            if (seen_mode) {
                if (searchable(v) && !explore_seen_get(e,ny * GM_N + nx)) frontier = true;
                if (v == 255) continue;
            } else if (v == 255) { frontier = true; continue; }
            if (v >= NP_COST_LETHAL) continue;
            /* 车贴墙起步时前几格也在近墙带里，允许从起点走出 2 格 */
            if (s_bd[ny * GM_N + nx] != 0xFFFF && !(s_bd[ny * GM_N + nx] == 0xFFFE && d < 2)) continue;
            s_bd[ny * GM_N + nx] = (uint16_t)(d + 1);
            s_bq[qt++] = (uint16_t)(ny * GM_N + nx);
        }
        if (!frontier || d < min_cells) continue;
        /* 紧挨致命格的边界（平台/坡道侧沿外被遮挡的一侧）多半下不去，不选；
         * 有图搜索的边界来自相机视场而不是遮挡，墙边的边界正常，不做这项过滤 */
        bool near_leth = false;
        for (int yy = y - 1; !seen_mode && yy <= y + 1 && !near_leth; yy++)
            for (int xx = x - 1; xx <= x + 1; xx++)
                if (xx >= 0 && yy >= 0 && xx < GM_N && yy < GM_N && gm->grid[yy * GM_N + xx] == NP_COST_LETHAL) {
                    near_leth = true; break;
                }
        if (near_leth) continue;
        e->n_frontier++;
        int32_t fx, fy;
        gmap_cell_to_mm(gm, mi, x, y, &fx, &fy);
        if (fx_dist(fx - pose->x, fy - pose->y) < c->frontier_min_mm) continue;   /* 直线距离也要够远（否则一选就"到达"） */
        bool bl = false;
        for (int b = 0; b < e->bl_n; b++)
            if (blacklist_within_1000(fx,fy,e->bl_x[b],e->bl_y[b])) { bl = true; break; }
        if (bl) continue;
        int32_t cost = (int32_t)d * 10 + c->w_visited * e->visited[vis_idx(fx, fy)];
        if (cost < best_cost) { best_cost = cost; best = i; }
    }
    if(!nav_app_search_checkpoint()) return false;
    if (best < 0) return false;
    gmap_cell_to_mm(gm, mi, best % GM_N, best / GM_N, gx, gy);
    return true;
}
