#ifndef MAP_REVALIDATE_H
#define MAP_REVALIDATE_H
#include "map_ray_clear.h"
#include "nav_task.h"
#include "lidar_cal.h"
bool hal_clear_depth_begin(uint32_t capture_us);
uint16_t hal_clear_depth_pixel(int u,int v);
bool hal_clear_read(int32_t gx,int32_t gy,rc_cell_t*);
bool hal_clear_drop(const rc_cell_t*);
void map_revalidate_reset(void);
void map_revalidate_before_fuse(nav_task_t*,const lidar_cal_t*,const int32_t r[3][3],const int32_t t[3],uint32_t capture_us);
void map_revalidate_diagnostics(uint32_t*);
#endif
