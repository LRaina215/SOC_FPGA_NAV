/* Navigation CPU reference/implementation. No simulator or geometry truth.
 * An entire old height prism must project inside a valid raw-depth patch,
 * whose every return is at least 100mm beyond its farthest corner, in three
 * distinct accepted capture epochs. Missing/foreground rays veto deletion.
 * Compare-and-invalidate prevents deleting a cell updated after validation.
 */
#include "map_ray_clear.h"
#include "fixmath.h"
#include <string.h>
#include <limits.h>
#define B 20
#define ONE (1<<B)
static int32_t qm(int32_t a,int32_t b){return (int32_t)(((int64_t)a*b)>>B);}
static int32_t f32q(uint32_t v){
 int e=(int)((v>>23)&255);if(!e)return 0;
 if(e==255)return 0;
 int64_t m=(v&0x7fffff)|0x800000;int shift=e-150+B;
 int64_t q=shift>=0?(shift<36?m<<shift:INT32_MAX):shift>-40?(m+((int64_t)1<<(-shift-1)))>>-shift:0;
 if(q>INT32_MAX)q=INT32_MAX;return v>>31?-(int32_t)q:(int32_t)q;
}
void rc_init(rc_state_t *s){memset(s,0,sizeof(*s));}
void rc_lens(rc_state_t *s,const uint32_t bits[9]){for(int i=0;i<9;i++)s->lens[i]=f32q(bits[i]);}
static int floorq(int32_t x){return x>=0?x/ONE:-((int64_t)-x+ONE-1)/ONE;}
static int ceilq(int32_t x){return -floorq(-x);}
static bool project(const rc_state_t *s,const int32_t p[3],int32_t *u,int32_t *v){
 if(p[0]<20)return false;
 int32_t x=(int32_t)(((int64_t)p[1]*ONE)/p[0]),y=(int32_t)((-(int64_t)p[2]*ONE)/p[0]);
 if(x>2*ONE || x<-2*ONE || y>ONE || y<-ONE)return false;
 int32_t xx=qm(x,x),yy=qm(y,y),xy=qm(x,y),r=xx+yy;
 int32_t rad=ONE+qm(r,s->lens[4]+qm(r,s->lens[5]+qm(r,s->lens[6])));
 int32_t xd=qm(x,rad)+2*qm(s->lens[7],xy)+qm(s->lens[8],r+2*xx);
 int32_t yd=qm(y,rad)+qm(s->lens[7],r+2*yy)+2*qm(s->lens[8],xy);
 *u=159*ONE-(qm(s->lens[0],xd)+s->lens[2]);*v=qm(s->lens[1],yd)+s->lens[3];
 return true;
}
static bool corner_cut(int u,int v){
 int x=159-u,y=v;
 return (x<30 && ((y<30 && (30-x)*(30-x)+(30-y)*(30-y)>900) ||
                  (y>30 && (30-x)*(30-x)+(y-30)*(y-30)>900))) ||
        (x>130 && ((y<30 && (x-130)*(x-130)+(30-y)*(30-y)>900) ||
                   (y>30 && (x-130)*(x-130)+(y-30)*(y-30)>900)));
}
static uint16_t filtered(rc_depth_t get,void *ctx,int u,int v){
 if(corner_cut(u,v))return 0;
 uint16_t c=get(ctx,u,v),p=get(ctx,u-1,v),n=get(ctx,u+1,v);
 int th=50+(c>>4),a=(int)c-p,b=(int)c-n;
 if(a<0)a=-a;if(b<0)b=-b;
 return c && p && n && a>th && b>th?0:c;
}
static bool proof(rc_state_t *s,const rc_cell_t *c,const int32_t r[3][3],const int32_t t[3],uint16_t inv,
                  rc_depth_t get,rc_ray_t ray,void *ctx,int *budget){
 int32_t umin=INT32_MAX,umax=INT32_MIN,vmin=INT32_MAX,vmax=INT32_MIN;uint32_t far=0;
 int32_t x0=(int32_t)(((int64_t)c->gx*65536)/inv),x1=(int32_t)(((int64_t)(c->gx+1)*65536)/inv);
 int32_t y0=(int32_t)(((int64_t)c->gy*65536)/inv),y1=(int32_t)(((int64_t)(c->gy+1)*65536)/inv);
 int32_t lo[3]={x0,y0,c->lo-20},hi[3]={x1,y1,c->hi+20};
 for(int i=0;i<8;i++){
  int32_t w[3]={(i&1?x1:x0)-t[0],(i&2?y1:y0)-t[1],(i&4?hi[2]:lo[2])-t[2]},p[3];
  for(int j=0;j<3;j++)p[j]=(int32_t)(((int64_t)r[0][j]*w[0]+(int64_t)r[1][j]*w[1]+(int64_t)r[2][j]*w[2])>>14);
  int32_t u,v;if(!project(s,p,&u,&v)){s->diag[4]++;return false;}
  if(u<umin)umin=u;if(u>umax)umax=u;if(v<vmin)vmin=v;if(v>vmax)vmax=v;
  uint32_t dist=fx_isqrt((uint64_t)((int64_t)p[0]*p[0]+(int64_t)p[1]*p[1]+(int64_t)p[2]*p[2]));if(dist>far)far=dist;
 }
 int u0=floorq(umin)-1,u1=ceilq(umax)+1,v0=floorq(vmin)-1,v1=ceilq(vmax)+1;
 s->diag[10]=(uint32_t)(u1-u0+1);s->diag[11]=(uint32_t)(v1-v0+1);
 if(u0<1 || u1>158 || v0<1 || v1>58 || (u1-u0+1)*(v1-v0+1)>1024){s->diag[4]++;return false;}
 (void)ray;
 for(int v=v0;v<=v1;v++)for(int u=u0;u<=u1;u++){
  if(!*budget){s->diag[9]++;return false;}(*budget)--;
  /* Entire expanded bounding patch, including rays outside the prism, must
   * be free. This is conservative and avoids a per-pixel inverse-lens solve
   * on the soft CPU. No missing/foreground sample can become free evidence. */
  uint16_t d=filtered(get,ctx,u,v);s->diag[8]++;
  if(d<100 || d>20000){s->diag[5]++;return false;}
  if(d<=far+100){s->diag[6]++;return false;}
 }
 s->diag[2]++;return true;
}
bool rc_probe(rc_state_t *s,const rc_cell_t *c,const int32_t r[3][3],const int32_t t[3],uint16_t inv,rc_depth_t get,rc_ray_t ray,void *ctx){
 int budget=8192;return proof(s,c,r,t,inv,get,ray,ctx,&budget);
}
void rc_frame(rc_state_t *s,const int32_t r[3][3],const int32_t t[3],uint32_t capture_us,int32_t ground_z,
              const uint8_t *cost,int32_t cx,int32_t cy,uint16_t inv,
              rc_read_t read,rc_depth_t get,rc_ray_t ray,rc_drop_t drop,void *ctx){
 if(!inv || !s->lens[0] || (s->last_frame && (int32_t)(capture_us-s->last_frame)<=0))return;
 s->last_frame=capture_us;s->diag[0]++;
 /* Nearest eligible stale/sparse lethal cells first; all selection uses the
  * firmware cost map and old height, not a simulator's false-obstacle mask. */
 rc_cell_t cells[RC_N];uint32_t dist[RC_N];int nc=0;
 for(int y=0;y<128;y++)for(int x=0;x<128;x++){
  if(cost[y*128+x]!=254)continue;
  int32_t gx=cx-64+x,gy=cy-64+y;
  int32_t dx=(int32_t)(((int64_t)gx*65536+32768)/inv)-t[0],dy=(int32_t)(((int64_t)gy*65536+32768)/inv)-t[1];
  uint32_t d=(uint32_t)((int64_t)dx*dx+(int64_t)dy*dy);if(d>1300u*1300u)continue;
  rc_cell_t c;if(!read(ctx,gx,gy,&c) || c.count<4 || c.age<3 || c.hi-ground_z<40 || c.hi-c.lo>180)continue;
  int k=nc;if(k==RC_N){if(d>=dist[k-1])continue;k--;}
  while(k>0 && d<dist[k-1]){if(k<RC_N){cells[k]=cells[k-1];dist[k]=dist[k-1];}k--;}
  cells[k]=c;dist[k]=d;if(nc<RC_N)nc++;
 }
 rc_pending_t next[RC_N];memset(next,0,sizeof next);int budget=1024;
 for(int j=0;j<nc;j++){
  rc_cell_t *c=&cells[j];s->diag[1]++;
  rc_pending_t old={0};for(int k=0;k<RC_N;k++)if(s->cell[k].used && s->cell[k].gx==c->gx && s->cell[k].gy==c->gy){old=s->cell[k];break;}
  bool same=old.used && old.tag==c->tag && old.stamp==c->stamp && (uint32_t)(capture_us-old.last_us)<=350000;
  if(!proof(s,c,r,t,inv,get,ray,ctx,&budget))continue;
  uint8_t n=same?(uint8_t)(old.n+1):1;
  if(n>=3){if(drop(ctx,c))s->diag[3]++;else s->diag[7]++;}
  else next[j]=(rc_pending_t){c->gx,c->gy,capture_us,c->tag,c->stamp,n,1};
 }
 memcpy(s->cell,next,sizeof next);
}
