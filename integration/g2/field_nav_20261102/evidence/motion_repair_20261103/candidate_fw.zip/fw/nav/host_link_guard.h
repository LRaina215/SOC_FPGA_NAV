/* Independent candidate: packet-arrival lease, not physical standstill proof. */
#ifndef HOST_LINK_GUARD_H
#define HOST_LINK_GUARD_H
#include "proto.h"
#define HOST_LINK_TIMEOUT_US 250000u /* candidate parameter, not an accepted stop deadline */
typedef struct {
    uint32_t last_rx_us, locked_since_us, accepted, rejected, timeouts;
    bool have_rx, locked, timed_out;
} host_link_guard_t;
extern host_link_guard_t g_host_link_guard;
void host_link_guard_init(host_link_guard_t *g,uint32_t now);
bool host_link_guard_poll(host_link_guard_t *g,uint32_t now);
bool host_link_guard_observe(host_link_guard_t *g,const proto_msg_t *m,uint32_t now,uint32_t rx_us);
void host_link_guard_filter(host_link_guard_t *g,uint32_t now,nav_cmd_t *cmd);
#endif
