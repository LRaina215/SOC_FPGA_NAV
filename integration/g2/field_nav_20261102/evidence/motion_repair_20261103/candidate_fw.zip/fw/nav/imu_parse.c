#include "imu_parse.h"
#include "fixmath.h"

void imu_parser_init(imu_parser_t *p, imu_proto_t proto)
{
    *p = (imu_parser_t){0};
    p->proto = proto;
}

/* 度 ×32768/180 -> angle（65536/360）：angle = raw * 65536/360 * 180/32768 = raw（量纲恰好一致） */
static angle_t wit_angle(uint8_t lo, uint8_t hi) { return (angle_t)(int16_t)(lo | (hi << 8)); }

/* 控制机身系 (X 右, Y 前, Z 上) -> 导航机身系 (X 前, Y 左, Z 上)：nav = (ctrl_y, -ctrl_x, ctrl_z)。
 * 只按两套坐标定义推导，BMI088 实际安装方向须装车用手倾斜核对，错了改这三行即可。 */
#ifndef IMU_BMI_NAV_X
#define IMU_BMI_NAV_X(cx, cy, cz) (cy)
#define IMU_BMI_NAV_Y(cx, cy, cz) (-(cx))
#define IMU_BMI_NAV_Z(cx, cy, cz) (cz)
#endif

static int16_t le16(const uint8_t *b) { return (int16_t)(b[0] | (b[1] << 8)); }

static int16_t sat16(int32_t v) { return (int16_t)(v > 32767 ? 32767 : v < -32768 ? -32768 : v); }

/* 重力单位向量（导航机身系，指向下方；水平时 (0,0,-1)）-> 与 WIT 角度帧同约定的俯仰/横滚：
 * 姿态 R = Rz(yaw)·Ry(pitch)·Rx(roll)，机身系重力 = (sin p, -sin r cos p, -cos r cos p)，pitch>0 为低头。 */
static void bmi_attitude(imu_parser_t *p, int32_t cx, int32_t cy, int32_t cz)
{
    int32_t x = IMU_BMI_NAV_X(cx, cy, cz), y = IMU_BMI_NAV_Y(cx, cy, cz), z = IMU_BMI_NAV_Z(cx, cy, cz);
    p->pitch = fx_atan2(x, (int32_t)fx_isqrt((uint64_t)((int64_t)y * y + (int64_t)z * z)));
    p->roll = fx_atan2(-y, -z);
    p->yaw = 0;
}

/* Q9 rad/s -> WIT 原始单位（×2000/32768 °/s）：raw = q9 / 512 × (180/π) × 32768/2000 ≈ q9 × 1877/1024 */
static int16_t bmi_gyro_raw(int32_t q9) { return sat16((int32_t)(((int64_t)q9 * 1877) / 1024)); }

bool imu_parser_feed(imu_parser_t *p, uint8_t b, bool first, uint32_t t_us)
{
    if (first) {
        p->t_burst = t_us;
        /* 片内 BMI 帧对总在突发起点开始：丢过字节后不靠碰运气找 0x55，从这里重新对齐 */
        if (p->proto == IMU_PROTO_BMI_INTERNAL) p->n = 0;
    }
    if (p->n == 0 && b != 0x55) return false;
    p->buf[p->n++] = b;
    if (p->n < 11) return false;
    p->n = 0;
    uint8_t sum = 0;
    for (int i = 0; i < 10; i++) sum = (uint8_t)(sum + p->buf[i]);
    if (sum != p->buf[10]) { p->n_bad++; return false; }
    p->n_ok++;
    if (p->proto == IMU_PROTO_BMI_INTERNAL) {
        int32_t a = le16(p->buf + 2), c = le16(p->buf + 4), e = le16(p->buf + 6);
        if (p->buf[1] == 0x5C) {                  /* 角速度帧（控制机身系 Q9 rad/s） */
            p->gx = bmi_gyro_raw(IMU_BMI_NAV_X(a, c, e));
            p->gy = bmi_gyro_raw(IMU_BMI_NAV_Y(a, c, e));
            p->gz = bmi_gyro_raw(IMU_BMI_NAV_Z(a, c, e));
            p->gyro_t_us = p->t_burst;
            p->gyro_new = true;
            return false;
        }
        if (p->buf[1] != 0x5B) return false;      /* 重力帧（控制机身系 Q12） */
        bmi_attitude(p, a, c, e);
        p->bmi_seq = (uint16_t)le16(p->buf + 8);
        p->att_t_us = p->t_burst;
        p->att_new = true;
        return true;
    }
    if (p->buf[1] == 0x52) {                      /* 角速度帧 */
        p->gx = (int16_t)(p->buf[2] | (p->buf[3] << 8));
        p->gy = (int16_t)(p->buf[4] | (p->buf[5] << 8));
        p->gz = (int16_t)(p->buf[6] | (p->buf[7] << 8));
        p->gyro_t_us = p->t_burst;
        p->gyro_new = true;
        return false;
    }
    if (p->buf[1] != 0x53) return false;
    p->roll  = wit_angle(p->buf[2], p->buf[3]);
    p->pitch = wit_angle(p->buf[4], p->buf[5]);
    p->yaw   = wit_angle(p->buf[6], p->buf[7]);
    p->att_t_us = p->t_burst;
    p->att_new = true;
    return true;
}
