#include "map_revalidate.h"
#ifndef APP_RAY_CLEAR_ENABLE
#define APP_RAY_CLEAR_ENABLE 0
#endif
#if APP_RAY_CLEAR_ENABLE
static rc_state_t state;
static bool rd(void *ctx,int32_t x,int32_t y,rc_cell_t *v){(void)ctx;return hal_clear_read(x,y,v);}
static uint16_t pixel(void *ctx,int u,int v){(void)ctx;return hal_clear_depth_pixel(u,v);}
static void ray(void *ctx,int u,int v,int16_t out[3]){lidar_cal_pixel((const lidar_cal_t*)ctx,v*160+u,out);}
static bool drop(void *ctx,const rc_cell_t *v){(void)ctx;return hal_clear_drop(v);}
void map_revalidate_reset(void){rc_init(&state);}
void map_revalidate_diagnostics(uint32_t *v){for(int i=0;i<12;i++)v[i]=state.diag[i];}
void map_revalidate_before_fuse(nav_task_t *nt,const lidar_cal_t *cal,const int32_t r[3][3],const int32_t t[3],uint32_t capture_us){
 if(!nt->have_map || !hal_clear_depth_begin(capture_us))return;
 rc_lens(&state,cal->lens);
 rc_frame(&state,r,t,capture_us,nt->pose.cur.z,nt->map,nt->mi.cx,nt->mi.cy,nt->mi.inv_res,rd,pixel,ray,drop,(void*)cal);
}
#else
void map_revalidate_reset(void){}
void map_revalidate_diagnostics(uint32_t *v){for(int i=0;i<12;i++)v[i]=0;}
void map_revalidate_before_fuse(nav_task_t *nt,const lidar_cal_t *cal,const int32_t r[3][3],const int32_t t[3],uint32_t cap){
 (void)nt;(void)cal;(void)r;(void)t;(void)cap;
}
#endif
