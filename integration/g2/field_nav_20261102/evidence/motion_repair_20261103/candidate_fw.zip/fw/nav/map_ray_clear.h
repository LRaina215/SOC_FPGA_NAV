#ifndef MAP_RAY_CLEAR_H
#define MAP_RAY_CLEAR_H
#include <stdint.h>
#include <stdbool.h>
#define RC_N 16
typedef struct { int32_t gx,gy; int16_t lo,hi; uint8_t tag,stamp,count,age; } rc_cell_t;
typedef struct {int32_t gx,gy;uint32_t last_us;uint8_t tag,stamp,n,used;} rc_pending_t;
typedef struct {rc_pending_t cell[RC_N];uint32_t last_frame;uint32_t diag[12];int32_t lens[9];} rc_state_t;
typedef bool (*rc_read_t)(void*,int32_t,int32_t,rc_cell_t*);
typedef uint16_t (*rc_depth_t)(void*,int,int);
typedef void (*rc_ray_t)(void*,int,int,int16_t[3]);
typedef bool (*rc_drop_t)(void*,const rc_cell_t*);
void rc_init(rc_state_t*);
void rc_lens(rc_state_t*,const uint32_t bits[9]);
bool rc_probe(rc_state_t*,const rc_cell_t*,const int32_t[3][3],const int32_t[3],uint16_t,rc_depth_t,rc_ray_t,void*);
void rc_frame(rc_state_t*,const int32_t r[3][3],const int32_t t[3],uint32_t capture_us,int32_t ground_z,
              const uint8_t *cost,int32_t cx,int32_t cy,uint16_t inv_res,
              rc_read_t,rc_depth_t,rc_ray_t,rc_drop_t,void*);
#endif
