#include "gmap.h"
#include "nav_params.h"

#define LN NP_MAP_N
#define UNSEEN (-128)
/* 先验图里的障碍是实测的真值：实时观测只能添加障碍，不能把它抹掉。
 * 否则定位一偏，墙所在的格子在错位的局部图里被看成空地，连看三帧就从规划栅格里消失，A* 直接穿墙。 */
#ifndef GM_PRIOR_FIXED
#define GM_PRIOR_FIXED 1
#endif
/* 有先验图时全局规划只用先验图（GM_PRIOR_LIVE=0 时）。实时观测里有扶车人的腿、定位偏几度时错位的墙，原样加进规划栅格
 * 会把通道"堵死"，A* 就绕到车后面去（11-01 实测下发目标后先原地左转 150° 朝向车后）。 */
#ifndef GM_PRIOR_ONLY
#define GM_PRIOR_ONLY 1
#endif
/* 有图模式的实时障碍层：先验图里没有的障碍（新放的箱子、人）也进全局规划，A* 提前绕开，而不是开到跟前被足迹检查拦停。
 * 只在雷达修正近期有效（live_on）时加证据、进栅格：纯推算时位姿会偏，看到的真墙落成假墙（11-02 14:05 无人时堵死小道口）。
 * 实时观测有假障碍：ToF 飞点集中在 1.5 m 外的深度边缘（11-02 开机采样：1.5 m 内地面误判 0.1%，2.5 m 内 2.2%），
 * 定位偏时墙会错位成第二道墙。所以只收这样的观测：
 *   - 离车 GM_LIVE_R 格以内看到的致命格才加证据，更远的只用来清除；
 *   - 证据 >= GM_LIVE_THR（连续两次更新都看到）才进规划栅格；
 *   - 离先验墙 1 格以内的观测算作那堵墙本身，不另加（错位的墙不会把 1 m 的通道挤窄）；
 *   - 看到可通行就减证据；每 GM_DECAY_UPD 次更新所有正证据减 1，看不到的障碍（转身后、局部图过期后）几秒后消失。 */
#ifndef GM_PRIOR_LIVE
#define GM_PRIOR_LIVE 1
#endif
#ifndef GM_LIVE_R
#define GM_LIVE_R 20
#endif
#define GM_LIVE_THR 4
#define GM_DECAY_UPD 10

static int32_t fdiv(int32_t a, int32_t b) { return (a >= 0) ? a / b : -((-a + b - 1) / b); }

void gmap_default_cfg(gmap_cfg_t *c)
{
    c->occ_hit = 2;
    c->occ_miss = -1;
    c->occ_max = 6;
    c->occ_min = -4;
    c->occ_thr = 2;
    c->min_known = (GM_DS * GM_DS * 3 + 7) / 8;      /* 一格内至少 3/8 的局部格已知（4×4 时 6、2×2 时 2） */
}

void gmap_init(gmap_t *g)
{
    gmap_cfg_t c = g->cfg;
    *g = (gmap_t){0};
    g->cfg = c;
    for (int i = 0; i < GM_N * GM_N; i++) { g->occ[i] = UNSEEN; g->cost[i] = 0; g->grid[i] = 255; g->prior[i] = 255; }
}

static bool near_prior_wall(const gmap_t *g, int i)
{
    int x = i % GM_N, y = i / GM_N;
    for (int yy = nav_max32(0, y - 1); yy <= nav_min32(GM_N - 1, y + 1); yy++)
        for (int xx = nav_max32(0, x - 1); xx <= nav_min32(GM_N - 1, x + 1); xx++)
            if (g->prior[yy * GM_N + xx] == NP_COST_LETHAL) return true;
    return false;
}

static void compose_rows(gmap_t *g,int row0,int row1)
{
    const gmap_cfg_t *c = &g->cfg;
    for (int i = row0*GM_N; i < row1*GM_N; i++) {
        int o = g->occ[i];
        uint8_t obs = (o == UNSEEN) ? 255 : (o >= c->occ_thr) ? NP_COST_LETHAL : g->cost[i];
        uint8_t pr = g->has_prior ? g->prior[i] : 255;
        if (GM_PRIOR_LIVE && g->has_prior)
            g->grid[i] = (g->live_on && pr != NP_COST_LETHAL && o != UNSEEN && o >= GM_LIVE_THR && !near_prior_wall(g, i)) ?
                         NP_COST_LETHAL : pr;
        else if (GM_PRIOR_ONLY && g->has_prior) g->grid[i] = pr;
        else if (GM_PRIOR_FIXED && pr == NP_COST_LETHAL) g->grid[i] = pr;
        else if (obs == 255) g->grid[i] = pr;
        else if (pr == NP_COST_LETHAL && obs != NP_COST_LETHAL && o > c->occ_min + 1) g->grid[i] = pr;
        else g->grid[i] = obs;
    }
    for (int k = 0; k < GM_VBLK; k++) {
        if (!g->vblk[k].ttl) continue;
        int r = g->vblk[k].r, bx = g->vblk[k].gx - g->ox, by = g->vblk[k].gy - g->oy;
        for (int y = nav_max32(row0,by-r); y <= nav_min32(row1-1,by+r); y++)
            for (int x = bx - r; x <= bx + r; x++)
                if (x >= 0 && y >= 0 && x < GM_N && y < GM_N && (x - bx) * (x - bx) + (y - by) * (y - by) <= r * r + 1)
                    g->grid[y * GM_N + x] = NP_COST_LETHAL;
    }
}

static void compose(gmap_t *g) {compose_rows(g,0,GM_N);}

void gmap_set_live(gmap_t *g, bool on)
{
    if (g->live_on == on) return;
    g->live_on = on;
    if (!g->has_prior) return;
    compose(g);
    g->n_shift++;
}

static void reset_work(gmap_t *g) {
    for(int y=0;y<GM_N;y++) g->row_seq[y]=0;
    g->work_active=false;g->work_done=false;g->work_row=0;
}

void gmap_block_add(gmap_t *g, const hal_map_info_t *mi, int32_t x, int32_t y, int r, int ttl)
{
    int gx, gy;
    gmap_mm_to_cell(g, mi, x, y, &gx, &gy);
    int k = 0;
    for (int i = 1; i < GM_VBLK; i++) if (g->vblk[i].ttl < g->vblk[k].ttl) k = i;     /* 替换剩余时间最短的 */
    g->vblk[k].gx = (int16_t)(gx + g->ox); g->vblk[k].gy = (int16_t)(gy + g->oy);      /* 存绝对粗格坐标（栅格平移后仍有效） */
    g->vblk[k].r = (uint8_t)r;
    g->vblk[k].ttl = (uint16_t)ttl;
    compose(g);
    g->n_shift++;                   /* 路径失效，重规划 */
}

void gmap_clear_obs(gmap_t *g)
{
    reset_work(g);
    g->ready=g->has_prior;
    for (int i = 0; i < GM_N * GM_N; i++) { g->occ[i] = UNSEEN; g->cost[i] = 0; }
    if (!g->has_prior) g->init = false;
    compose(g);
    g->n_shift++;                   /* 已有路径失效 */
}

void gmap_prior_begin(gmap_t *g, int32_t gox, int32_t goy, int gnx, int gny)
{
    (void)gnx; (void)gny;
    for (int i = 0; i < GM_N * GM_N; i++) g->prior[i] = 255;
    g->has_prior = false;
    g->pgnx = gnx;
    g->pox = gox; g->poy = goy;
}

void gmap_prior_put(gmap_t *g, int i, uint8_t v)
{
    int x = i % g->pgnx, y = i / g->pgnx;
    if (x < GM_N && y < GM_N) g->prior[y * GM_N + x] = v;
}

void gmap_prior_done(gmap_t *g)
{
    reset_work(g);
    for (int i = 0; i < GM_N * GM_N; i++) { g->occ[i] = UNSEEN; g->cost[i] = 0; }
    g->ox = g->pox; g->oy = g->poy;
    g->init = true;
    g->has_prior = true;
    g->ready=true;
    g->n_shift++;
    compose(g);
}

void gmap_prior_drop(gmap_t *g)
{
    g->has_prior = false;
    gmap_clear_obs(g);
}

static int32_t fine_idx(int32_t v_mm, uint16_t inv) { return (int32_t)(((int64_t)v_mm * inv) >> 16); }

void gmap_mm_to_cell(const gmap_t *g, const hal_map_info_t *mi, int32_t x, int32_t y, int *gx, int *gy)
{
    uint16_t inv = mi->inv_res ? mi->inv_res : 1311;
    *gx = fdiv(fine_idx(x, inv), GM_DS) - g->ox;
    *gy = fdiv(fine_idx(y, inv), GM_DS) - g->oy;
}

void gmap_cell_to_mm(const gmap_t *g, const hal_map_info_t *mi, int gx, int gy, int32_t *x, int32_t *y)
{
    uint16_t inv = mi->inv_res ? mi->inv_res : 1311;
    int64_t fx = (int64_t)(gx + g->ox) * GM_DS, fy = (int64_t)(gy + g->oy) * GM_DS;
    *x = (int32_t)((fx * 65536 + GM_DS * 32768) / inv);
    *y = (int32_t)((fy * 65536 + GM_DS * 32768) / inv);
}

/* 原地平移：new[y][x] = old[y+sy][x+sx]，越界填未观测 */
static void shift(gmap_t *g, int sx, int sy)
{
    int y0 = sy >= 0 ? 0 : GM_N - 1, y1 = sy >= 0 ? GM_N : -1, ys = sy >= 0 ? 1 : -1;
    int x0 = sx >= 0 ? 0 : GM_N - 1, x1 = sx >= 0 ? GM_N : -1, xs = sx >= 0 ? 1 : -1;
    for (int y = y0; y != y1; y += ys)
        for (int x = x0; x != x1; x += xs) {
            int i = y * GM_N + x, oxx = x + sx, oyy = y + sy;
            if (oxx >= 0 && oxx < GM_N && oyy >= 0 && oyy < GM_N) {
                int j = oyy * GM_N + oxx;
                g->occ[i] = g->occ[j];
                g->cost[i] = g->cost[j];
            } else {
                g->occ[i] = UNSEEN;
                g->cost[i] = 0;
            }
        }
    g->ox += sx;
    g->oy += sy;
    g->n_shift++;
    reset_work(g);compose(g);
}

static void prepare(gmap_t *g,const hal_map_info_t *mi,int32_t rx,int32_t ry)
{
    uint16_t inv = mi->inv_res ? mi->inv_res : 1311;
    int32_t rcx = fdiv(fine_idx(rx, inv), GM_DS), rcy = fdiv(fine_idx(ry, inv), GM_DS);
    g->rcx = rcx; g->rcy = rcy;
    if (!g->init) {
        g->ox = rcx - GM_N / 2;
        g->oy = rcy - GM_N / 2;
        g->init = true;
    } else if (!g->has_prior) {
        int lx = rcx - g->ox, ly = rcy - g->oy;
        int sx = 0, sy = 0;
        if (lx < GM_N / 4 || lx >= GM_N - GM_N / 4) sx = lx - GM_N / 2;
        if (ly < GM_N / 4 || ly >= GM_N - GM_N / 4) sy = ly - GM_N / 2;
        if (sx || sy) shift(g, sx, sy);
    }
}

static void observe_rows(gmap_t *g,const uint8_t *map,const hal_map_info_t *mi,int row0,int row1)
{
    const gmap_cfg_t *c=&g->cfg;
    /* 完整落在局部窗口内的粗格 */
    int32_t f0x = mi->cx - LN / 2, f0y = mi->cy - LN / 2;
    int32_t cgx0 = -fdiv(-f0x, GM_DS), cgy0 = -fdiv(-f0y, GM_DS);       /* 向上取整 */
    int32_t cgx1 = fdiv(f0x + LN, GM_DS), cgy1 = fdiv(f0y + LN, GM_DS);  /* 不含 */
    for (int32_t cgy = nav_max32(cgy0,g->oy+row0); cgy < nav_min32(cgy1,g->oy+row1); cgy++) {
        int gy = cgy - g->oy;
        for (int32_t cgx = cgx0; cgx < cgx1; cgx++) {
            int gx = cgx - g->ox;
            if (gx < 0 || gx >= GM_N) continue;
            int wx0 = cgx * GM_DS - f0x, wy0 = cgy * GM_DS - f0y;
            int nk = 0, nl = 0, nb = 0, mc = 0;
            for (int j = 0; j < GM_DS; j++)
                for (int i = 0; i < GM_DS; i++) {
                    uint8_t v = map[(wy0 + j) * LN + wx0 + i];
                    if (v == NP_COST_UNKNOWN) continue;
                    nk++;
                    if (v >= GM_COST_BLOCKED) nb++;
                    if (v == NP_COST_LETHAL) nl++;
                    /* 253是中心规划的足迹净空代价，不能在细格->记忆粗格时丢掉。
                     * 它不增加原始障碍的占用证据，仍与254分开；新自由观测可替换。 */
                    else if (v > mc) mc = v;
                }
            if (nk < c->min_known) continue;
            int k = gy * GM_N + gx;
            int o = g->occ[k];
            int d = (nl >= (GM_DS * GM_DS >= 16 ? 2 : 1)) ? c->occ_hit : c->occ_miss;     /* 4×4 时 2 格致命、2×2 时 1 格 */
            if (GM_PRIOR_LIVE && g->has_prior && d > 0 && (!g->live_on ||
                (cgx - g->rcx) * (cgx - g->rcx) + (cgy - g->rcy) * (cgy - g->rcy) > GM_LIVE_R * GM_LIVE_R)) continue;
            o = (o == UNSEEN) ? d : o + d;
            if (o > c->occ_max) o = c->occ_max;
            if (o < c->occ_min) o = c->occ_min;
            g->occ[k] = (int8_t)o;
            /* 全粗格都受限才保留253硬净空；混合格保留252高代价，
             * 允许细图/完整足迹在其中寻找接入，不能封死跨粗格边界的窄带。 */
            g->cost[k] = (uint8_t)((mc == GM_COST_BLOCKED && nb < GM_DS * GM_DS) ? GM_COST_PARTIAL : mc);
        }
    }
}

static void live_decay(gmap_t *g)
{
    if (!GM_PRIOR_LIVE || !g->has_prior || g->n_upd % GM_DECAY_UPD) return;
    unsigned n = 0;
    for (int i = 0; i < GM_N * GM_N; i++) {
        if (g->occ[i] > 0) g->occ[i]--;
        if (g->grid[i] == NP_COST_LETHAL && g->prior[i] != NP_COST_LETHAL) n++;
    }
    g->n_live = (uint16_t)n;
}

void gmap_update(gmap_t *g,const uint8_t *map,const hal_map_info_t *mi,int32_t rx,int32_t ry)
{
    prepare(g,mi,rx,ry);observe_rows(g,map,mi,0,GM_N);
    for(int k=0;k<GM_VBLK;k++) if(g->vblk[k].ttl) g->vblk[k].ttl--;
    g->n_upd++;live_decay(g);
    compose(g);g->ready=true;reset_work(g);
}

bool gmap_update_rows(gmap_t *g,const uint8_t *map,const hal_map_info_t *mi,int32_t rx,int32_t ry,int rows)
{
    if(!mi->seq || rows<=0) return false;
    if(!g->work_active || g->work_seq!=mi->seq) {
        unsigned age=g->work_active?(uint16_t)(mi->seq-g->work_seq):1;
        prepare(g,mi,rx,ry);
        for(int k=0;k<GM_VBLK;k++) {
            unsigned ttl=g->vblk[k].ttl;
            g->vblk[k].ttl=(uint16_t)(ttl>age?ttl-age:0);
        }
        g->work_seq=mi->seq;g->work_active=true;g->work_done=false;
    }
    if(g->work_done) return false;
    rows=nav_min32(rows,GM_N);
    for(int n=0;n<rows;) {
        int y=g->work_row;
        int count=1;
        if(g->row_seq[y]!=mi->seq) {
            while(n+count<rows && y+count<GM_N && g->row_seq[y+count]!=mi->seq) count++;
            observe_rows(g,map,mi,y,y+count);compose_rows(g,y,y+count);
            for(int i=y;i<y+count;i++) g->row_seq[i]=mi->seq;
        }
        n+=count;g->work_row=(uint16_t)((y+count)%GM_N);
        if(!g->work_row) {
            bool all=true;for(int i=0;i<GM_N;i++) if(g->row_seq[i]!=mi->seq) {all=false;break;}
            if(all) {g->work_done=true;g->ready=true;g->n_upd++;live_decay(g);break;}
        }
    }
    return true;
}
