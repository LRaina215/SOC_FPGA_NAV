/* 导航任务：三种运行模式（PDF 选题 3 架构）共用同一张代价图与局部规划器。
 *   GOTO   定点/路径点导航：A*（粗栅格）给出全局路径 -> 前视点 -> 局部规划
 *   TRACK  目标跟踪：RK3588 目标 -> 里程计系 -> 站位点 -> 同 GOTO；目标丢失转 SEARCH
 *   SEARCH 自主探索：方向打分选探索点 -> 同 GOTO；发现目标转 TRACK
 * nav_task_step() 以固定周期调用（默认 10 Hz），只通过 hal_* 访问硬件。
 */
#ifndef NAV_TASK_H
#define NAV_TASK_H

#include "nav_types.h"
#include "hal.h"
#include "pose.h"
#include "target.h"
#include "astar.h"
#include "gmap.h"
#include "local_planner.h"
#include "motion_guard.h"
#include "explore.h"
#include "proto.h"
#include "local_frame.h"

#ifndef APP_FLAT_GROUND
#define APP_FLAT_GROUND 1   /* 平地测试阶段：看不清的地方当平地；规划与发送之间换了一帧图不作废指令 */
#endif

typedef struct {
    int32_t  lookahead_mm;       /* 路径前视距离 */
    uint32_t replan_us;          /* A* 最短重规划间隔 */
    uint32_t blocked_us;         /* 持续无可行候选多久判为受阻 */
    uint32_t search_repick_us;   /* 探索点最长保持时间 */
    int32_t  track_hold_mm;      /* 跟踪：到达站位点后原地保持的容差 */
    int32_t  wp_tol_mm;          /* 中间路径点的到达容差（比终点宽：只是途经） */
    uint32_t stall_us;           /* 这么久位移不到 stall_mm 视为卡住，执行脱困动作 */
    int32_t  stall_mm;
    int32_t  near_goal_mm;       /* 此范围内卡住时保持停止/受阻，不冒充到达或盲目恢复 */
    uint32_t settle_us;          /* 最终目标内，实际速度持续稳定多久才声明到达 */
    int32_t  goal_pose_margin_mm; /* 物理到达要求中预留的定位误差预算，离线假设、待实测 */
    uint32_t recover_us;         /* 脱困动作时长 */
} nav_task_cfg_t;

typedef struct {
    nav_task_cfg_t cfg;
    lp_cfg_t       lp_cfg;
    astar_cfg_t    as_cfg;       /* 局部图上的 A*（use_gmap=false 时） */
    astar_cfg_t    as_cfg_g;     /* 全局记忆栅格上的 A* */
    bool           use_gmap;
    bool           async_gmap,search_work_done;
    bool scan_active,scan_settling,scan_failed;
    angle_t scan_last_yaw;
    int32_t scan_turned;
    uint32_t scan_start_us,scan_settle_us;
    bool scan_exit_valid;
    int8_t scan_dir;
    int32_t scan_exit_x,scan_exit_y;
    explore_cfg_t  ex_cfg;

    nav_mode_t mode;
    uint8_t    state;
    int32_t    goal_x, goal_y;
    int32_t    wp_x[PROTO_MAX_WP], wp_y[PROTO_MAX_WP];
    int        wp_n, wp_i;
    bool       wp_loop;

    pose_est_t pose;
    local_frame_t terrain_frame;
    bool stepping_local;
    target_t   tgt;
    bool track_holding, track_goal_valid;  /* 跟踪启停回差与已锁定站位点 */
    explore_t  exp;

    uint8_t        map[NP_MAP_N * NP_MAP_N];
    hal_map_info_t mi;
    bool           have_map;
    gmap_t         gm;
    astar_path_t   path;             /* use_gmap：gmap 栅格坐标；否则局部图窗口坐标 */
    uint32_t       path_shift;       /* 规划时 gmap 的平移计数（平移后路径坐标失效） */
    uint16_t       path_seq;
    uint32_t       path_t_us;
    uint32_t       settle_t_us;
    bool           path_valid;
    bool           path_complete;    /* A*到达未裁剪的目标；部分路径不替换成最终目标 */
    bool           path_target_is_goal;
    int32_t        plan_goal_x,plan_goal_y;
    bool           search_fine,search_keep_route;
    bool           bg_done;          /* 空闲时段已把进行中的 A* 算完，结果码在 bg_rc，待规划周期登记 */
    int8_t         bg_rc;
    uint32_t       search_shift;
    bool           settling;
    bool           path_fine;        /* 原分辨率近场路径；固定其生成窗口原点 */
    bool           refine_path;      /* 粗路径无可执行接入/局部受阻后才请求细化 */
    int32_t        path_cx, path_cy;
    lp_result_t    lp;
    nav_cmd_t      cmd;
    uint8_t        cmd_source, motion_result; /* 本周期提议来源与最终检查结果 */
    uint32_t       last_ok_us;       /* 最近一次找到可行候选 */
    uint32_t       search_t_us;
    bool           search_goal_valid;
    int32_t        look_x, look_y;   /* 当前前视点（调试/显示） */
    bool           turning;          /* 原地转向对准前视点中 */
    int32_t        prog_x, prog_y;   /* 卡住检测参考点 */
    int16_t        progress_speed;  /* 上一周期通过最终检查的平移速度幅值 */
    uint32_t       prog_t_us;
    uint32_t       recover_until_us;
    bool           recovering;
    int8_t         recover_dir;      /* 1 = 倒车，0 = 原地转 */
    uint32_t       n_recover;
    int32_t        stuck_x, stuck_y; /* 上一次卡住的位置 */
    bool           hold;             /* 定位未就绪：原地保持（速度为零、保持平衡），模式与目标不变 */
    bool           slow;             /* 定位退化：限速一半 */
    int16_t        hold_wz;          /* 保持期间的原地转向角速度（对准换视角），0 = 静止 */
    bool           stale;            /* 位姿跳变后，seq 仍为 stale_seq 的代价图是旧坐标系下的，不用 */
    uint16_t       stale_seq;
    uint32_t       t_look_max, t_chk_max; /* 控制台每秒打印后清零：路径前视点 / 最终指令检查的最长耗时 us */
    int16_t        look_i;           /* 前视点在路径上的序号（调试） */
    bool           hold_ref;         /* 位置保持：已记下保持起点 */
    int32_t        hold_x, hold_y, hold_ef; /* 保持起点；沿车头方向偏移的低通值 mm */
    uint32_t       look_path_t;      /* look_i 所属路径的生成时刻（path_t_us） */
    int16_t        v_prev;           /* 上一周期实际下发的前进速度（斜坡起点） */
    uint16_t       n_mfail, n_pbusy, n_stall; /* 诊断：最终足迹检查不过 / 重规划期间没有可用路径 / 卡住恢复 */
    int64_t progress_travel_um;
    uint32_t recheck_since_us,recheck_until_us;
    uint16_t recheck_rejects;
    uint8_t recheck_phase;
    angle_t recheck_yaw;
    int32_t observe_x,observe_y,observe_gx,observe_gy;
    uint32_t observe_cooldown;
    uint16_t observe_started,observe_completed;
    bool revisit_goal;
    uint32_t revisit_until_us;
    uint8_t        last_mfail;       /* 最近一次足迹检查不过的结果码 */
} nav_task_t;

void nav_task_init(nav_task_t *nt);
/* 处理一条主机报文（rx_us 为到达时间） */
void nav_task_on_msg(nav_task_t *nt, const proto_msg_t *m, uint32_t rx_us);
/* 设置模式 / 目标（本地调用接口，报文处理也走这里） */
void nav_task_set_mode(nav_task_t *nt, nav_mode_t mode);
void nav_task_set_goal(nav_task_t *nt, int32_t x, int32_t y);
/* 周期调用：规划并下发速度指令 */
void nav_task_step(nav_task_t *nt, uint32_t now_us);
void nav_task_map_work(nav_task_t *nt,int rows);
/* 空闲轮询：继续进行中的 A* 搜索 */
void nav_task_plan_work(nav_task_t *nt);
/* 生成状态报文内容 */
void nav_task_status(const nav_task_t *nt, proto_status_t *s, uint32_t now_us);

/* 坐标换算工具 */
void nav_mm_to_win(const hal_map_info_t *mi, int32_t x, int32_t y, int *wx, int *wy);
void nav_win_to_mm(const hal_map_info_t *mi, int wx, int wy, int32_t *x, int32_t *y);

#endif
