/* 硬件抽象层：导航算法（fw/nav）只通过这些函数访问硬件。
 *   上板：fw/drv/hal_fpga.c（寄存器访问 nav_subsystem）
 *   主机测试：fw/test/hal_sim.c（仿真世界）
 */
#ifndef NAV_HAL_H
#define NAV_HAL_H

#include "nav_types.h"
#include "nav_params.h"

#define HAL_MAP_N NP_MAP_N

/* ---- 时间 ---- */
uint32_t hal_time_us(void);

/* ---- 代价图（前台） ---- */
typedef struct {
    uint16_t seq;           /* 每次新代价图加 1 */
    int32_t  cx, cy;        /* 窗口中心世界栅格 */
    int32_t  res_mm;        /* 栅格分辨率 */
    uint16_t inv_res;       /* 65536 / res_mm */
} hal_map_info_t;

bool    hal_map_info(hal_map_info_t *mi);
/* 按窗口坐标复制：out[wy*N + wx]，wx = ix - (cx - N/2)。返回seq；0表示无效/复制中切图，不得使用out。 */
uint16_t hal_map_copy(uint8_t *out, hal_map_info_t *mi);

/* ---- 轨迹评估（硬件加速）---- */
typedef struct { int16_t dvx, dvy, dth; } hal_cand_t;      /* 格 Q8/步，angle/步 */
typedef struct {
    uint8_t  max_cost, n_unknown, coll_step;
    bool     collide, left;
    uint32_t sum_cost;
    int32_t  end_x, end_y;                                  /* 世界栅格 Q8 */
} hal_traj_res_t;
/* 起点为世界栅格 Q8 与航向；阻塞直到完成。返回 false 表示评估期间地图已更新，调用方不得提交该结果。 */
bool hal_traj_eval(const hal_cand_t *c, int k, int t, int32_t x0_q8, int32_t y0_q8, angle_t th0,
                   uint8_t cmax, hal_traj_res_t *res);

/* ---- 底盘 ---- */
void hal_send_cmd(const nav_cmd_t *cmd);
/* 读取底盘回传（里程计速度）。返回是否有新数据 */
bool hal_odom(int16_t *vx, int16_t *vy, int16_t *wz, uint32_t *t_us);

/* ---- 雷达：初始化、帧尾信息、方向查找表 ---- */
/* 打开帧位姿握手（LIDAR.CTRL.WAIT_POSE），格式位保持复位缺省值（厂家 SDK 格式） */
void     hal_lidar_init(void);
/* FrameInfo 锁存次数（0 = 还没收到带 FrameInfo 的帧）；hal_lidar_lens 取最近一帧的内参（float32 原始位） */
uint32_t hal_lidar_info_seq(void);
void     hal_lidar_lens(uint32_t lens[9]);
/* 从像素 idx 起写 n 项方向（每项 rx, ry, rz，12 位 Q0.11） */
void     hal_lidar_lut_write(uint32_t idx, const int16_t *rxyz, int n);

/* ---- 雷达口原始帧（软核 TCP 客户端启动雷达用，fw/nav/xt_link.c） ---- */
typedef struct {
    uint8_t  mac[6];        /* 本机（FPGA 雷达口） */
    uint32_t ip;            /* 本机 IP */
    uint32_t lidar_ip;      /* 雷达 IP（NETL.LIDAR_IP） */
    bool     tcp_en;        /* NETL.CTRL.LIDAR_TCP：允许软核连 TCP 启动雷达 */
} hal_netl_cfg_t;
void     hal_netl_cfg(hal_netl_cfg_t *c);
/* 发送整帧（以太网头起，不含 FCS，<= 128 字节）；发送通道忙时返回 false */
bool     hal_lraw_send(const uint8_t *frame, int len);
/* 取一帧（发给本机的 ARP 应答或 TCP 段），返回整帧字节数（含 FCS；只拷前 min(len, max, 128) 字节），没有返回 0 */
int      hal_lraw_recv(uint8_t *buf, int max);
/* 已成功接收的雷达帧数（LIDAR.STAT_FRAMES） */
uint32_t hal_lidar_frames(void);

/* ---- 雷达帧位姿握手 ---- */
/* 有一帧点云在等待位姿时返回 true，并给出该帧到达时间 */
bool hal_lidar_waiting(uint32_t *frame_t_us);
/* 写入 雷达->里程计 变换（R Q14，t mm）、本帧地图窗口中心、保留点高度带（里程计系 mm），并放行该帧 */
void hal_lidar_commit(const int32_t r_q14[3][3], const int32_t t_mm[3], int32_t cx, int32_t cy,
                      int32_t zmin, int32_t zmax, uint32_t capture_us);
enum { HAL_LIDAR_NORMAL, HAL_LIDAR_MATCH_ONLY, HAL_LIDAR_FUSE_ONLY };
void hal_lidar_stage(int stage); /* MATCH_ONLY保留原帧，FUSE_ONLY重读后释放 */

/* ---- 匹配定位（SLF，硬件并行打分）----
 * 提交帧（hal_lidar_commit）时硬件同时提取竖直结构点存入点缓冲（按提交时的位姿变换）。
 * hal_match_ready：本帧结构点已就绪、可以打分。
 * hal_match_start：发起打分——对缓冲点施加每个候选增量 p' = Rz(dyaw)·(p - c) + c + (dx, dy)，c = (cx_mm, cy_mm)，
 *   与结构图比较。返回 false 表示硬件不支持（固件退回纯航位推算）。
 * hal_match_result：打分完成时返回 true 并填结果：n_valid = 参与打分的点数，
 *   cost = Σ 点到结构线法向距离（1/16 格，截断），n_in = 近邻命中点数，n_pts = 抽样后的结构点总数（门控前）。
 * hal_match_update：把缓冲点按最终修正量（同样的变换形式）并入结构图（修正量为 0 也要调用）。 */
/* 与硬件候选/结果寄存器的16bit字段一致；内部数组布局不属于外部协议。
 * Python桥显式扩为int32/uint32，不能直接memcpy此结构。 */
typedef struct { int16_t dx,dy,dyaw; } hal_match_cand_t;
typedef struct { uint16_t n_valid,n_in;uint32_t cost,n_pts; } hal_match_res_t;
bool hal_match_ready(void);
/* 返回前已向硬件/仿真复制全部候选，调用者可复用c的存储。 */
bool hal_match_start(int32_t cx_mm, int32_t cy_mm, const hal_match_cand_t *c, int k);
bool hal_match_result(hal_match_res_t *res, int k);
void hal_match_lf_forward(int32_t distance_mm, angle_t yaw);
/* 无图 SLF 窗口中心固定在里程计系 (x_mm, y_mm) */
void hal_match_lf_center_mm(int32_t x_mm, int32_t y_mm);
void hal_match_update(int32_t dx, int32_t dy, int32_t dyaw, int32_t cx_mm, int32_t cy_mm);
/* 读高程图某点（里程计系 mm）所在栅格的地面高度：[zmin, zmax] 区间中点（格内高差 > 40 mm 视为非地面）。
 * 栅格有效返回 true。上板实现走 MAP.ELEV_ADDR/ELEV_CMD/ELEV_Q0/Q1 */
bool hal_map_height(int32_t x_mm, int32_t y_mm, int32_t *h_mm);
/* 原始观测区间；true只表示同代读有效，不表示可行或新鲜。
 * 保留的过期危险仍可阻挡运动，但不能证明当前轮下地面。 */
typedef struct {
    int16_t lo,hi;
    uint16_t seq;
    uint8_t count,age;
    uint16_t coverage; /*4x4 known subregions, capture-time limited*/
    bool retained_stale;
    bool coverage_retained_stale; /* Separate fine coverage age from height retention. */
} hal_support_t;
bool hal_map_support(int32_t x_mm,int32_t y_mm,hal_support_t *out);
/* 清空高程图（位姿跳变到地图系后，旧坐标系下融合的内容作废） */
void hal_map_clear(void);

/* ---- 有图模式（先验定位图）----
 * hal_prior_begin：清空结构图、暂停在线并图（下载期间匹配不可用）。
 * hal_prior_write：写一个结构图槽字（18 位，格式见 model/slf_match.py pack_hi）。
 * hal_prior_enable(true, ox, oy)：进入有图模式——似然场窗口原点固定为 (ox, oy)（全局 5 cm 格），
 *   UPDATE 不再并图（只释放点缓冲），打分时槽字标签与点所在格不符视为无结构。false：清空并回到在线建图。
 * hal_match_gate(false)：打分不做门控（初始对准 / 重定位：位姿误差大时门控会挡掉正确的点）。 */
void hal_prior_begin(void);
void hal_prior_write(uint16_t slot, uint32_t word);
void hal_prior_enable(bool en, int32_t ox, int32_t oy);
void hal_match_gate(bool on);
/* 结构点高度带（相对机器人足底 mm）：有图模式放宽下限（脚下的路沿/平台侧面也在先验图里） */
void hal_match_zband(int32_t lo, int32_t hi);

/* ---- IMU 原始字节 ---- */
/* 取一个字节；first 表示突发首字节，t_us 为其到达时间（仅 first 时有效）。无数据返回 false */
bool hal_imu_byte(uint8_t *b, bool *first, uint32_t *t_us);
/* IMU 串口波特率分频（核心时钟 / 波特率） */
void hal_imu_config(uint32_t baud_div);
/* 清空字节与时间戳 FIFO，使两者重新一一对应（最长阻塞 50 ms） */
void hal_imu_resync(void);
/* 接收 FIFO 溢出累计次数 / 当前字节 FIFO 占用 */
uint32_t hal_imu_ovf(void);
uint32_t hal_imu_level(void);
/* 平地测试用地形阈值：台阶 100 mm、粗糙度 150 mm、坡度升高 200，并清空局部图 */
void hal_map_flat_ground(void);

/* ---- 主机报文（RK3588 / PC，网口或串口注入，见 proto.h）---- */
/* 取一个报文，返回长度（0 表示没有）；t_us 为到达时间 */
int  hal_host_recv(uint8_t *buf, int maxlen, uint32_t *t_us);
bool hal_host_send(const uint8_t *buf, int len);

#endif
